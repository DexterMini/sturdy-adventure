"""
Team Configuration Models for NordicAI Hub
"""

from sqlalchemy import Column, Integer, String, Boolean, JSON, ForeignKey, DateTime, Text
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class TeamConfig(Base):
    """
    Represents a user's AI team configuration
    """
    __tablename__ = "team_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=False)  # Will be linked to user system later
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=False)
    
    # Orchestrator configuration
    orchestrator_model = Column(String(50), nullable=False, default="gpt-4o")
    
    # Collaboration strategy
    collaboration_strategy = Column(String(50), nullable=False, default="expert_panel")
    
    # Cost and performance preferences
    cost_preference = Column(String(20), default="balanced")  # "cost", "quality", "speed", "balanced"
    max_cost_per_request = Column(Integer, default=100)  # in cents
    
    # Tool access permissions
    tool_access = Column(JSON, default=list)  # List of allowed tools
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    agents = relationship("TeamAgent", back_populates="team_config", cascade="all, delete-orphan")
    
    def to_dict(self):
        """Convert to dictionary for API responses"""
        return {
            "id": self.id,
            "user_id": self.user_id,
            "name": self.name,
            "description": self.description,
            "is_active": self.is_active,
            "orchestrator_model": self.orchestrator_model,
            "collaboration_strategy": self.collaboration_strategy,
            "cost_preference": self.cost_preference,
            "max_cost_per_request": self.max_cost_per_request,
            "tool_access": self.tool_access,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "agents": [agent.to_dict() for agent in self.agents]
        }

class TeamAgent(Base):
    """
    Represents an individual AI agent within a team configuration
    """
    __tablename__ = "team_agents"
    
    id = Column(Integer, primary_key=True, index=True)
    team_config_id = Column(Integer, ForeignKey("team_configs.id"), nullable=False)
    
    # Agent configuration
    role = Column(String(50), nullable=False)  # e.g., "coder", "researcher", "critic"
    model = Column(String(50), nullable=False)  # e.g., "gpt-4o-mini", "claude-3.5-sonnet"
    
    # Agent-specific settings
    system_prompt = Column(Text, nullable=True)  # Custom system prompt for this agent
    temperature = Column(Integer, default=70)  # Temperature * 100 (0-100)
    max_tokens = Column(Integer, default=2000)
    
    # Agent capabilities
    can_use_tools = Column(Boolean, default=True)
    priority = Column(Integer, default=1)  # Execution priority (1 = highest)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    team_config = relationship("TeamConfig", back_populates="agents")
    
    def to_dict(self):
        """Convert to dictionary for API responses"""
        return {
            "id": self.id,
            "team_config_id": self.team_config_id,
            "role": self.role,
            "model": self.model,
            "system_prompt": self.system_prompt,
            "temperature": self.temperature / 100.0,  # Convert back to 0.0-1.0 range
            "max_tokens": self.max_tokens,
            "can_use_tools": self.can_use_tools,
            "priority": self.priority,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }

class TeamSession(Base):
    """
    Represents an active team collaboration session
    """
    __tablename__ = "team_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    team_config_id = Column(Integer, ForeignKey("team_configs.id"), nullable=False)
    user_id = Column(Integer, nullable=False)
    
    # Session data
    user_prompt = Column(Text, nullable=False)
    orchestrator_plan = Column(Text, nullable=True)
    current_phase = Column(String(50), default="planning")
    status = Column(String(20), default="active")  # "active", "completed", "failed"
    
    # Results and costs
    final_result = Column(Text, nullable=True)
    total_tokens_used = Column(Integer, default=0)
    total_cost_cents = Column(Integer, default=0)
    
    # Timing
    started_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)
    
    # Session logs (for debugging and transparency)
    execution_log = Column(JSON, default=list)  # List of execution steps
    
    def to_dict(self):
        """Convert to dictionary for API responses"""
        return {
            "id": self.id,
            "team_config_id": self.team_config_id,
            "user_id": self.user_id,
            "user_prompt": self.user_prompt,
            "orchestrator_plan": self.orchestrator_plan,
            "current_phase": self.current_phase,
            "status": self.status,
            "final_result": self.final_result,
            "total_tokens_used": self.total_tokens_used,
            "total_cost_cents": self.total_cost_cents,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "execution_log": self.execution_log
        }

# Default team configurations for new users
DEFAULT_TEAM_CONFIGS = [
    {
        "name": "Coding Team",
        "description": "Specialized team for software development tasks",
        "orchestrator_model": "gpt-4o",
        "collaboration_strategy": "sequential_execution",
        "cost_preference": "balanced",
        "tool_access": ["code_interpreter", "web_search", "file_system"],
        "agents": [
            {
                "role": "researcher",
                "model": "gpt-4o-mini",
                "system_prompt": "You are a research specialist. Your job is to gather information, understand requirements, and provide comprehensive background research for coding tasks.",
                "priority": 1
            },
            {
                "role": "coder",
                "model": "gpt-4o",
                "system_prompt": "You are an expert software developer. Write clean, efficient, and well-documented code. Follow best practices and consider edge cases.",
                "priority": 2
            },
            {
                "role": "critic",
                "model": "claude-3.5-sonnet",
                "system_prompt": "You are a code reviewer and quality assurance specialist. Review code for bugs, security issues, performance problems, and adherence to best practices.",
                "priority": 3
            }
        ]
    },
    {
        "name": "Analysis Team",
        "description": "Team optimized for data analysis and research tasks",
        "orchestrator_model": "claude-3.5-sonnet",
        "collaboration_strategy": "debate_mode",
        "cost_preference": "quality",
        "tool_access": ["web_search", "code_interpreter"],
        "agents": [
            {
                "role": "researcher",
                "model": "claude-3.5-sonnet",
                "system_prompt": "You are a research analyst. Gather comprehensive information, verify facts, and provide detailed analysis with proper citations.",
                "priority": 1
            },
            {
                "role": "data_analyst",
                "model": "gpt-4o",
                "system_prompt": "You are a data analysis expert. Process data, create visualizations, and derive meaningful insights from complex datasets.",
                "priority": 1
            },
            {
                "role": "critic",
                "model": "gpt-4o-mini",
                "system_prompt": "You are a critical thinker. Challenge assumptions, identify potential biases, and ensure the analysis is thorough and accurate.",
                "priority": 2
            }
        ]
    },
    {
        "name": "Creative Team",
        "description": "Team for creative writing and content generation",
        "orchestrator_model": "claude-3.5-sonnet",
        "collaboration_strategy": "expert_panel",
        "cost_preference": "quality",
        "tool_access": ["web_search"],
        "agents": [
            {
                "role": "creative_writer",
                "model": "claude-3.5-sonnet",
                "system_prompt": "You are a creative writer. Generate engaging, original content with strong narrative flow and compelling language.",
                "priority": 1
            },
            {
                "role": "editor",
                "model": "gpt-4o",
                "system_prompt": "You are an editor. Improve clarity, flow, grammar, and overall quality of written content while preserving the author's voice.",
                "priority": 2
            },
            {
                "role": "fact_checker",
                "model": "gpt-4o-mini",
                "system_prompt": "You are a fact-checker. Verify claims, check for accuracy, and ensure all information is correct and properly sourced.",
                "priority": 2
            }
        ]
    }
]

