"""
Dexinity AI Studio API Routes for NordicAI Hub
Provides direct access to Dexinity AI Studio tools
"""

from flask import Blueprint, request, jsonify
from typing import Dict, Any
import asyncio
from datetime import datetime

from ..tools.dexinity_tool import DexinityToolManager

# Create blueprint
dexinity_bp = Blueprint('dexinity', __name__, url_prefix='/api/dexinity')

# Initialize Dexinity tool manager
dexinity_manager = DexinityToolManager()

@dexinity_bp.route('/tools', methods=['GET'])
def get_dexinity_tools():
    """Get list of available Dexinity AI Studio tools"""
    try:
        tools = dexinity_manager.get_available_tools()
        
        return jsonify({
            "success": True,
            "tools": tools,
            "total_tools": len(tools)
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@dexinity_bp.route('/generate/image', methods=['POST'])
def generate_image():
    """Generate an image using Dexinity AI Studio"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if 'prompt' not in data:
            return jsonify({
                "success": False,
                "error": "Missing required field: prompt"
            }), 400
        
        # Extract parameters
        prompt = data['prompt']
        style = data.get('style')
        brand_assets = data.get('brand_assets', [])
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                dexinity_manager.execute_tool(
                    "dexinity_generate_image",
                    prompt=prompt,
                    style=style,
                    brand_assets=brand_assets
                )
            )
        finally:
            loop.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@dexinity_bp.route('/generate/video', methods=['POST'])
def generate_video():
    """Generate a video using Dexinity AI Studio"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if 'prompt' not in data:
            return jsonify({
                "success": False,
                "error": "Missing required field: prompt"
            }), 400
        
        # Extract parameters
        prompt = data['prompt']
        duration = data.get('duration', 30)
        style = data.get('style')
        
        # Validate duration
        if not isinstance(duration, int) or duration < 5 or duration > 120:
            return jsonify({
                "success": False,
                "error": "Duration must be an integer between 5 and 120 seconds"
            }), 400
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                dexinity_manager.execute_tool(
                    "dexinity_generate_video",
                    prompt=prompt,
                    duration=duration,
                    style=style
                )
            )
        finally:
            loop.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@dexinity_bp.route('/resize', methods=['POST'])
def magic_resize():
    """Resize an image for social media platforms using Dexinity's Magic Resize"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['image_url', 'platform']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    "success": False,
                    "error": f"Missing required field: {field}"
                }), 400
        
        # Extract parameters
        image_url = data['image_url']
        platform = data['platform']
        
        # Validate platform
        supported_platforms = [
            'instagram', 'facebook', 'twitter', 'linkedin', 
            'youtube', 'tiktok', 'pinterest', 'snapchat'
        ]
        
        if platform.lower() not in supported_platforms:
            return jsonify({
                "success": False,
                "error": f"Unsupported platform. Supported platforms: {', '.join(supported_platforms)}"
            }), 400
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                dexinity_manager.execute_tool(
                    "dexinity_magic_resize",
                    image_url=image_url,
                    platform=platform.lower()
                )
            )
        finally:
            loop.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@dexinity_bp.route('/sketch-to-mockup', methods=['POST'])
def sketch_to_mockup():
    """Convert a sketch to a polished mockup using Dexinity AI Studio"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if 'sketch_url' not in data:
            return jsonify({
                "success": False,
                "error": "Missing required field: sketch_url"
            }), 400
        
        # Extract parameters
        sketch_url = data['sketch_url']
        description = data.get('description')
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                dexinity_manager.execute_tool(
                    "dexinity_sketch_to_mockup",
                    sketch_url=sketch_url,
                    description=description
                )
            )
        finally:
            loop.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@dexinity_bp.route('/batch/generate', methods=['POST'])
def batch_generate():
    """Generate multiple assets in batch using Dexinity AI Studio"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if 'requests' not in data:
            return jsonify({
                "success": False,
                "error": "Missing required field: requests"
            }), 400
        
        requests_list = data['requests']
        
        if not isinstance(requests_list, list) or len(requests_list) == 0:
            return jsonify({
                "success": False,
                "error": "requests must be a non-empty list"
            }), 400
        
        # Limit batch size
        if len(requests_list) > 10:
            return jsonify({
                "success": False,
                "error": "Maximum batch size is 10 requests"
            }), 400
        
        # Process batch requests
        results = []
        total_cost = 0
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            for i, req in enumerate(requests_list):
                try:
                    # Validate request structure
                    if 'type' not in req:
                        results.append({
                            "success": False,
                            "error": "Missing 'type' field in request",
                            "request_index": i
                        })
                        continue
                    
                    req_type = req['type']
                    
                    # Route to appropriate tool
                    if req_type == 'image':
                        if 'prompt' not in req:
                            results.append({
                                "success": False,
                                "error": "Missing 'prompt' field for image request",
                                "request_index": i
                            })
                            continue
                        
                        result = loop.run_until_complete(
                            dexinity_manager.execute_tool(
                                "dexinity_generate_image",
                                prompt=req['prompt'],
                                style=req.get('style'),
                                brand_assets=req.get('brand_assets', [])
                            )
                        )
                    
                    elif req_type == 'video':
                        if 'prompt' not in req:
                            results.append({
                                "success": False,
                                "error": "Missing 'prompt' field for video request",
                                "request_index": i
                            })
                            continue
                        
                        result = loop.run_until_complete(
                            dexinity_manager.execute_tool(
                                "dexinity_generate_video",
                                prompt=req['prompt'],
                                duration=req.get('duration', 30),
                                style=req.get('style')
                            )
                        )
                    
                    elif req_type == 'resize':
                        required_fields = ['image_url', 'platform']
                        missing_fields = [f for f in required_fields if f not in req]
                        if missing_fields:
                            results.append({
                                "success": False,
                                "error": f"Missing fields for resize request: {', '.join(missing_fields)}",
                                "request_index": i
                            })
                            continue
                        
                        result = loop.run_until_complete(
                            dexinity_manager.execute_tool(
                                "dexinity_magic_resize",
                                image_url=req['image_url'],
                                platform=req['platform']
                            )
                        )
                    
                    elif req_type == 'mockup':
                        if 'sketch_url' not in req:
                            results.append({
                                "success": False,
                                "error": "Missing 'sketch_url' field for mockup request",
                                "request_index": i
                            })
                            continue
                        
                        result = loop.run_until_complete(
                            dexinity_manager.execute_tool(
                                "dexinity_sketch_to_mockup",
                                sketch_url=req['sketch_url'],
                                description=req.get('description')
                            )
                        )
                    
                    else:
                        results.append({
                            "success": False,
                            "error": f"Unsupported request type: {req_type}",
                            "request_index": i
                        })
                        continue
                    
                    # Add request index to result
                    result['request_index'] = i
                    results.append(result)
                    
                    # Accumulate cost
                    if result.get('success') and 'cost_estimate' in result:
                        cost_info = result['cost_estimate']
                        if isinstance(cost_info, dict) and 'estimated_cost_usd' in cost_info:
                            total_cost += cost_info['estimated_cost_usd']
                
                except Exception as req_error:
                    results.append({
                        "success": False,
                        "error": str(req_error),
                        "request_index": i
                    })
        
        finally:
            loop.close()
        
        # Calculate success rate
        successful_requests = sum(1 for r in results if r.get('success', False))
        success_rate = successful_requests / len(requests_list) if requests_list else 0
        
        return jsonify({
            "success": True,
            "results": results,
            "summary": {
                "total_requests": len(requests_list),
                "successful_requests": successful_requests,
                "failed_requests": len(requests_list) - successful_requests,
                "success_rate": success_rate,
                "total_estimated_cost_usd": total_cost
            }
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@dexinity_bp.route('/config', methods=['GET'])
def get_dexinity_config():
    """Get Dexinity AI Studio configuration and status"""
    try:
        # Check if Dexinity is properly configured
        is_configured = bool(dexinity_manager.dexinity_tool.slack_token)
        
        config_info = {
            "is_configured": is_configured,
            "mock_mode": dexinity_manager.dexinity_tool.mock_mode,
            "available_tools": len(dexinity_manager.get_available_tools()),
            "rate_limit_seconds": dexinity_manager.dexinity_tool.min_request_interval,
            "supported_platforms": [
                "instagram", "facebook", "twitter", "linkedin", 
                "youtube", "tiktok", "pinterest", "snapchat"
            ],
            "pricing_info": {
                "image_generation": "$0.29 per image",
                "video_generation": "$1.45 per video",
                "magic_resize": "$0.15 per resize",
                "sketch_to_mockup": "$0.35 per conversion",
                "currency": "USD",
                "pricing_tier": "starter"
            }
        }
        
        return jsonify({
            "success": True,
            "config": config_info
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

# Health check endpoint
@dexinity_bp.route('/health', methods=['GET'])
def dexinity_health():
    """Health check for Dexinity service"""
    try:
        # Test basic functionality
        tools = dexinity_manager.get_available_tools()
        
        return jsonify({
            "success": True,
            "service": "dexinity",
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "available_tools": len(tools),
            "mock_mode": dexinity_manager.dexinity_tool.mock_mode
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "service": "dexinity",
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

