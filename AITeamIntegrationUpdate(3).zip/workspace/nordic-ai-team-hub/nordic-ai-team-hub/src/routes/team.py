"""
Team API Routes for NordicAI Hub
Handles team configuration and collaboration endpoints
"""

from flask import Blueprint, request, jsonify
from typing import Dict, Any, List
import asyncio
from datetime import datetime

from ..models.team_config import TeamConfig, TeamAgent, TeamSession, DEFAULT_TEAM_CONFIGS
from ..services.team_orchestrator import TeamOrchestrator

# Create blueprint
team_bp = Blueprint('team', __name__, url_prefix='/api/team')

# Mock database storage (in production, use actual database)
team_configs_db: Dict[int, TeamConfig] = {}
team_sessions_db: Dict[int, TeamSession] = {}
next_config_id = 1
next_session_id = 1

def get_user_id() -> int:
    """Get current user ID (mock implementation)"""
    # In production, extract from JWT token or session
    return 1

@team_bp.route('/configs', methods=['GET'])
def get_team_configs():
    """Get all team configurations for the current user"""
    try:
        user_id = get_user_id()
        user_configs = [
            config.to_dict() for config in team_configs_db.values() 
            if config.user_id == user_id
        ]
        
        return jsonify({
            "success": True,
            "configs": user_configs
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/configs', methods=['POST'])
def create_team_config():
    """Create a new team configuration"""
    try:
        global next_config_id
        user_id = get_user_id()
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'orchestrator_model', 'collaboration_strategy']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    "success": False,
                    "error": f"Missing required field: {field}"
                }), 400
        
        # Create team configuration
        config = TeamConfig(
            id=next_config_id,
            user_id=user_id,
            name=data['name'],
            description=data.get('description', ''),
            orchestrator_model=data['orchestrator_model'],
            collaboration_strategy=data['collaboration_strategy'],
            cost_preference=data.get('cost_preference', 'balanced'),
            max_cost_per_request=data.get('max_cost_per_request', 100),
            tool_access=data.get('tool_access', []),
            is_active=data.get('is_active', False)
        )
        
        # Create agents
        agents_data = data.get('agents', [])
        for agent_data in agents_data:
            agent = TeamAgent(
                id=len(team_configs_db) * 10 + len(agents_data),  # Simple ID generation
                team_config_id=config.id,
                role=agent_data['role'],
                model=agent_data['model'],
                system_prompt=agent_data.get('system_prompt'),
                temperature=int(agent_data.get('temperature', 0.7) * 100),
                max_tokens=agent_data.get('max_tokens', 2000),
                can_use_tools=agent_data.get('can_use_tools', True),
                priority=agent_data.get('priority', 1)
            )
            config.agents.append(agent)
        
        # Store configuration
        team_configs_db[next_config_id] = config
        next_config_id += 1
        
        return jsonify({
            "success": True,
            "config": config.to_dict()
        }), 201
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/configs/<int:config_id>', methods=['GET'])
def get_team_config(config_id: int):
    """Get a specific team configuration"""
    try:
        user_id = get_user_id()
        
        if config_id not in team_configs_db:
            return jsonify({
                "success": False,
                "error": "Configuration not found"
            }), 404
        
        config = team_configs_db[config_id]
        
        # Check ownership
        if config.user_id != user_id:
            return jsonify({
                "success": False,
                "error": "Access denied"
            }), 403
        
        return jsonify({
            "success": True,
            "config": config.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/configs/<int:config_id>', methods=['PUT'])
def update_team_config(config_id: int):
    """Update a team configuration"""
    try:
        user_id = get_user_id()
        data = request.get_json()
        
        if config_id not in team_configs_db:
            return jsonify({
                "success": False,
                "error": "Configuration not found"
            }), 404
        
        config = team_configs_db[config_id]
        
        # Check ownership
        if config.user_id != user_id:
            return jsonify({
                "success": False,
                "error": "Access denied"
            }), 403
        
        # Update configuration
        if 'name' in data:
            config.name = data['name']
        if 'description' in data:
            config.description = data['description']
        if 'orchestrator_model' in data:
            config.orchestrator_model = data['orchestrator_model']
        if 'collaboration_strategy' in data:
            config.collaboration_strategy = data['collaboration_strategy']
        if 'cost_preference' in data:
            config.cost_preference = data['cost_preference']
        if 'max_cost_per_request' in data:
            config.max_cost_per_request = data['max_cost_per_request']
        if 'tool_access' in data:
            config.tool_access = data['tool_access']
        if 'is_active' in data:
            config.is_active = data['is_active']
        
        config.updated_at = datetime.utcnow()
        
        # Update agents if provided
        if 'agents' in data:
            # Clear existing agents
            config.agents = []
            
            # Add new agents
            for agent_data in data['agents']:
                agent = TeamAgent(
                    id=len(team_configs_db) * 10 + len(data['agents']),
                    team_config_id=config.id,
                    role=agent_data['role'],
                    model=agent_data['model'],
                    system_prompt=agent_data.get('system_prompt'),
                    temperature=int(agent_data.get('temperature', 0.7) * 100),
                    max_tokens=agent_data.get('max_tokens', 2000),
                    can_use_tools=agent_data.get('can_use_tools', True),
                    priority=agent_data.get('priority', 1)
                )
                config.agents.append(agent)
        
        return jsonify({
            "success": True,
            "config": config.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/configs/<int:config_id>', methods=['DELETE'])
def delete_team_config(config_id: int):
    """Delete a team configuration"""
    try:
        user_id = get_user_id()
        
        if config_id not in team_configs_db:
            return jsonify({
                "success": False,
                "error": "Configuration not found"
            }), 404
        
        config = team_configs_db[config_id]
        
        # Check ownership
        if config.user_id != user_id:
            return jsonify({
                "success": False,
                "error": "Access denied"
            }), 403
        
        # Delete configuration
        del team_configs_db[config_id]
        
        return jsonify({
            "success": True,
            "message": "Configuration deleted successfully"
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/chat/completions', methods=['POST'])
def team_chat_completions():
    """Process a team collaboration request"""
    try:
        user_id = get_user_id()
        data = request.get_json()
        
        # Validate required fields
        if 'message' not in data:
            return jsonify({
                "success": False,
                "error": "Missing required field: message"
            }), 400
        
        # Get team configuration
        config_id = data.get('team_config_id')
        if not config_id:
            # Use default active configuration
            active_configs = [
                config for config in team_configs_db.values()
                if config.user_id == user_id and config.is_active
            ]
            if not active_configs:
                return jsonify({
                    "success": False,
                    "error": "No active team configuration found"
                }), 400
            config = active_configs[0]
        else:
            if config_id not in team_configs_db:
                return jsonify({
                    "success": False,
                    "error": "Team configuration not found"
                }), 404
            config = team_configs_db[config_id]
            
            # Check ownership
            if config.user_id != user_id:
                return jsonify({
                    "success": False,
                    "error": "Access denied"
                }), 403
        
        # Create orchestrator and process request
        orchestrator = TeamOrchestrator(config)
        
        # Run async function in sync context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                orchestrator.process_request(data['message'], user_id)
            )
        finally:
            loop.close()
        
        # Store session if successful
        if result['success'] and 'session' in result:
            global next_session_id
            session_data = result['session']
            session = TeamSession(
                id=next_session_id,
                team_config_id=config.id,
                user_id=user_id,
                user_prompt=data['message'],
                orchestrator_plan=session_data.get('orchestrator_plan'),
                current_phase=session_data.get('current_phase'),
                status=session_data.get('status'),
                final_result=session_data.get('final_result'),
                total_tokens_used=session_data.get('total_tokens_used', 0),
                total_cost_cents=session_data.get('total_cost_cents', 0),
                started_at=datetime.fromisoformat(session_data['started_at']) if session_data.get('started_at') else datetime.utcnow(),
                completed_at=datetime.fromisoformat(session_data['completed_at']) if session_data.get('completed_at') else None,
                execution_log=session_data.get('execution_log', [])
            )
            team_sessions_db[next_session_id] = session
            result['session']['id'] = next_session_id
            next_session_id += 1
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/sessions', methods=['GET'])
def get_team_sessions():
    """Get team collaboration sessions for the current user"""
    try:
        user_id = get_user_id()
        user_sessions = [
            session.to_dict() for session in team_sessions_db.values()
            if session.user_id == user_id
        ]
        
        # Sort by most recent first
        user_sessions.sort(key=lambda x: x['started_at'], reverse=True)
        
        return jsonify({
            "success": True,
            "sessions": user_sessions
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/sessions/<int:session_id>', methods=['GET'])
def get_team_session(session_id: int):
    """Get a specific team collaboration session"""
    try:
        user_id = get_user_id()
        
        if session_id not in team_sessions_db:
            return jsonify({
                "success": False,
                "error": "Session not found"
            }), 404
        
        session = team_sessions_db[session_id]
        
        # Check ownership
        if session.user_id != user_id:
            return jsonify({
                "success": False,
                "error": "Access denied"
            }), 403
        
        return jsonify({
            "success": True,
            "session": session.to_dict()
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@team_bp.route('/models', methods=['GET'])
def get_available_models():
    """Get list of available AI models for team configuration"""
    models = [
        {
            "id": "gpt-4o",
            "name": "GPT-4o",
            "provider": "OpenAI",
            "description": "Most capable model for complex reasoning",
            "cost_per_1k_tokens": 3,
            "suitable_roles": ["orchestrator", "coder", "researcher", "critic"]
        },
        {
            "id": "gpt-4o-mini",
            "name": "GPT-4o Mini",
            "provider": "OpenAI", 
            "description": "Fast and cost-effective model",
            "cost_per_1k_tokens": 0.15,
            "suitable_roles": ["researcher", "critic", "creative_writer"]
        },
        {
            "id": "claude-3.5-sonnet",
            "name": "Claude 3.5 Sonnet",
            "provider": "Anthropic",
            "description": "Excellent for creative and analytical tasks",
            "cost_per_1k_tokens": 3,
            "suitable_roles": ["orchestrator", "creative_writer", "critic", "researcher"]
        },
        {
            "id": "gemini-1.5-pro",
            "name": "Gemini 1.5 Pro",
            "provider": "Google",
            "description": "Strong multimodal capabilities",
            "cost_per_1k_tokens": 2.5,
            "suitable_roles": ["researcher", "data_analyst", "creative_writer"]
        }
    ]
    
    return jsonify({
        "success": True,
        "models": models
    })

@team_bp.route('/strategies', methods=['GET'])
def get_collaboration_strategies():
    """Get list of available collaboration strategies"""
    strategies = [
        {
            "id": "expert_panel",
            "name": "Expert Panel",
            "description": "Each agent provides independent expertise, results are synthesized",
            "best_for": ["research", "analysis", "comprehensive solutions"],
            "execution_time": "medium",
            "cost": "medium"
        },
        {
            "id": "debate_mode",
            "name": "Debate Mode",
            "description": "Agents present solutions, debate merits, and refine through discussion",
            "best_for": ["complex decisions", "quality assurance", "creative solutions"],
            "execution_time": "high",
            "cost": "high"
        },
        {
            "id": "sequential_execution",
            "name": "Sequential Execution",
            "description": "Agents work in order, each building on previous work",
            "best_for": ["coding", "step-by-step processes", "workflows"],
            "execution_time": "medium",
            "cost": "medium"
        },
        {
            "id": "iterative_improvement",
            "name": "Iterative Improvement",
            "description": "Generate solution, critique, improve, repeat until optimal",
            "best_for": ["code optimization", "writing refinement", "quality improvement"],
            "execution_time": "high",
            "cost": "high"
        },
        {
            "id": "pair_programming",
            "name": "Pair Programming",
            "description": "Two agents work closely together, one creates, one reviews",
            "best_for": ["coding", "writing", "detailed work"],
            "execution_time": "medium",
            "cost": "medium"
        }
    ]
    
    return jsonify({
        "success": True,
        "strategies": strategies
    })

@team_bp.route('/defaults', methods=['POST'])
def create_default_configs():
    """Create default team configurations for a user"""
    try:
        global next_config_id
        user_id = get_user_id()
        
        created_configs = []
        
        for default_config in DEFAULT_TEAM_CONFIGS:
            # Create team configuration
            config = TeamConfig(
                id=next_config_id,
                user_id=user_id,
                name=default_config['name'],
                description=default_config['description'],
                orchestrator_model=default_config['orchestrator_model'],
                collaboration_strategy=default_config['collaboration_strategy'],
                cost_preference=default_config['cost_preference'],
                tool_access=default_config['tool_access'],
                is_active=(default_config['name'] == 'Coding Team')  # Make coding team active by default
            )
            
            # Create agents
            for agent_data in default_config['agents']:
                agent = TeamAgent(
                    id=next_config_id * 10 + agent_data['priority'],
                    team_config_id=config.id,
                    role=agent_data['role'],
                    model=agent_data['model'],
                    system_prompt=agent_data['system_prompt'],
                    priority=agent_data['priority'],
                    temperature=70,  # Default temperature
                    max_tokens=2000,
                    can_use_tools=True
                )
                config.agents.append(agent)
            
            # Store configuration
            team_configs_db[next_config_id] = config
            created_configs.append(config.to_dict())
            next_config_id += 1
        
        return jsonify({
            "success": True,
            "message": f"Created {len(created_configs)} default team configurations",
            "configs": created_configs
        }), 201
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

# Health check endpoint
@team_bp.route('/health', methods=['GET'])
def team_health():
    """Health check for team service"""
    return jsonify({
        "success": True,
        "service": "team",
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "stats": {
            "total_configs": len(team_configs_db),
            "total_sessions": len(team_sessions_db)
        }
    })

