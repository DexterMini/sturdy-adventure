"""
Team Orchestrator Service for NordicAI Hub
Handles coordination and execution of multi-AI team collaborations
"""

import asyncio
import json
import time
from typing import List, Dict, Any, Optional
from datetime import datetime
import openai
from ..models.team_config import TeamConfig, TeamAgent, TeamSession
from ..tools.dexinity_tool import DexinityToolManager

class TeamOrchestrator:
    """
    Main orchestrator class that manages AI team collaborations
    """
    
    def __init__(self, team_config: TeamConfig):
        self.team_config = team_config
        self.orchestrator_model = team_config.orchestrator_model
        self.agents = {agent.role: agent for agent in team_config.agents}
        self.tools = team_config.tool_access or []
        self.collaboration_strategy = team_config.collaboration_strategy
        self.cost_preference = team_config.cost_preference
        self.max_cost_cents = team_config.max_cost_per_request
        
        # Session tracking
        self.current_session: Optional[TeamSession] = None
        self.total_tokens_used = 0
        self.total_cost_cents = 0
        self.execution_log = []
        
        # Tool manager
        self.tool_manager = ToolManager()
        self.dexinity_tool_manager = DexinityToolManager()
    
    async def process_request(self, user_prompt: str, user_id: int) -> Dict[str, Any]:
        """
        Main entry point for processing a team request
        """
        # Create new session
        self.current_session = TeamSession(
            team_config_id=self.team_config.id,
            user_id=user_id,
            user_prompt=user_prompt,
            started_at=datetime.utcnow()
        )
        
        try:
            self._log_step("session_started", {"user_prompt": user_prompt})
            
            # Phase 1: Initial planning by orchestrator
            self.current_session.current_phase = "planning"
            orchestrator_plan = await self._create_initial_plan(user_prompt)
            self.current_session.orchestrator_plan = orchestrator_plan
            
            # Phase 2: Execute collaboration strategy
            self.current_session.current_phase = "execution"
            final_result = await self._execute_collaboration_strategy(user_prompt, orchestrator_plan)
            
            # Phase 3: Finalize results
            self.current_session.current_phase = "finalization"
            self.current_session.final_result = final_result
            self.current_session.status = "completed"
            self.current_session.completed_at = datetime.utcnow()
            self.current_session.total_tokens_used = self.total_tokens_used
            self.current_session.total_cost_cents = self.total_cost_cents
            self.current_session.execution_log = self.execution_log
            
            self._log_step("session_completed", {
                "final_result_length": len(final_result),
                "total_tokens": self.total_tokens_used,
                "total_cost_cents": self.total_cost_cents
            })
            
            return {
                "success": True,
                "result": final_result,
                "session": self.current_session.to_dict(),
                "metadata": {
                    "tokens_used": self.total_tokens_used,
                    "cost_cents": self.total_cost_cents,
                    "execution_time_seconds": (
                        self.current_session.completed_at - self.current_session.started_at
                    ).total_seconds(),
                    "agents_used": list(self.agents.keys()),
                    "collaboration_strategy": self.collaboration_strategy
                }
            }
            
        except Exception as e:
            self.current_session.status = "failed"
            self.current_session.completed_at = datetime.utcnow()
            self._log_step("session_failed", {"error": str(e)})
            
            return {
                "success": False,
                "error": str(e),
                "session": self.current_session.to_dict() if self.current_session else None
            }
    
    async def _create_initial_plan(self, user_prompt: str) -> str:
        """
        Create initial execution plan using the orchestrator model
        """
        self._log_step("planning_started", {"orchestrator_model": self.orchestrator_model})
        
        planning_prompt = self._build_planning_prompt(user_prompt)
        
        response = await self._call_ai_model(
            model=self.orchestrator_model,
            messages=[{"role": "system", "content": planning_prompt}],
            context="orchestrator_planning"
        )
        
        plan = response["content"]
        self._log_step("planning_completed", {"plan_length": len(plan)})
        
        return plan
    
    async def _execute_collaboration_strategy(self, user_prompt: str, plan: str) -> str:
        """
        Execute the chosen collaboration strategy
        """
        strategy_map = {
            "expert_panel": self._run_expert_panel,
            "debate_mode": self._run_debate_mode,
            "sequential_execution": self._run_sequential_execution,
            "iterative_improvement": self._run_iterative_improvement,
            "pair_programming": self._run_pair_programming
        }
        
        strategy_func = strategy_map.get(self.collaboration_strategy, self._run_expert_panel)
        self._log_step("strategy_execution_started", {"strategy": self.collaboration_strategy})
        
        result = await strategy_func(user_prompt, plan)
        
        self._log_step("strategy_execution_completed", {"result_length": len(result)})
        return result
    
    async def _run_expert_panel(self, user_prompt: str, plan: str) -> str:
        """
        Expert panel strategy: Each agent provides independent input
        """
        agent_results = {}
        
        # Execute agents in parallel for efficiency
        tasks = []
        for role, agent in self.agents.items():
            task = self._execute_agent(agent, user_prompt, plan, f"expert_panel_{role}")
            tasks.append((role, task))
        
        # Wait for all agents to complete
        for role, task in tasks:
            try:
                result = await task
                agent_results[role] = result["content"]
                self._log_step(f"agent_completed", {
                    "role": role,
                    "model": self.agents[role].model,
                    "tokens": result["tokens"],
                    "cost_cents": result["cost_cents"]
                })
            except Exception as e:
                self._log_step(f"agent_failed", {"role": role, "error": str(e)})
                agent_results[role] = f"Error: {str(e)}"
        
        # Synthesize results using orchestrator
        synthesis_result = await self._synthesize_results(user_prompt, agent_results, plan)
        return synthesis_result["content"]
    
    async def _run_debate_mode(self, user_prompt: str, plan: str) -> str:
        """
        Debate mode: Agents present solutions, debate, and refine
        """
        # Round 1: Initial contributions
        initial_contributions = {}
        for role, agent in self.agents.items():
            if role == "critic":  # Critics participate in later rounds
                continue
            
            result = await self._execute_agent(
                agent, user_prompt, plan, f"debate_initial_{role}"
            )
            initial_contributions[role] = result["content"]
        
        # Round 2: Critic provides feedback
        critic_agent = self.agents.get("critic")
        if critic_agent:
            critic_prompt = self._build_critic_prompt(user_prompt, initial_contributions)
            critic_result = await self._call_ai_model(
                model=critic_agent.model,
                messages=[{"role": "system", "content": critic_prompt}],
                context="debate_critic"
            )
            critic_feedback = critic_result["content"]
        else:
            # Use orchestrator as critic if no dedicated critic
            critic_feedback = await self._provide_orchestrator_feedback(user_prompt, initial_contributions)
        
        # Round 3: Agents revise based on feedback
        revised_contributions = {}
        for role, agent in self.agents.items():
            if role == "critic":
                revised_contributions[role] = critic_feedback
                continue
            
            revision_prompt = self._build_revision_prompt(
                user_prompt, initial_contributions[role], critic_feedback
            )
            
            result = await self._call_ai_model(
                model=agent.model,
                messages=[{"role": "system", "content": revision_prompt}],
                context=f"debate_revision_{role}"
            )
            revised_contributions[role] = result["content"]
        
        # Final synthesis
        synthesis_result = await self._synthesize_results(user_prompt, revised_contributions, plan)
        return synthesis_result["content"]
    
    async def _run_sequential_execution(self, user_prompt: str, plan: str) -> str:
        """
        Sequential execution: Agents work in order, each building on previous work
        """
        # Sort agents by priority
        sorted_agents = sorted(self.agents.items(), key=lambda x: x[1].priority)
        
        current_context = user_prompt
        execution_chain = []
        
        for role, agent in sorted_agents:
            sequential_prompt = self._build_sequential_prompt(
                user_prompt, current_context, plan, role, execution_chain
            )
            
            result = await self._call_ai_model(
                model=agent.model,
                messages=[{"role": "system", "content": sequential_prompt}],
                context=f"sequential_{role}"
            )
            
            current_context = result["content"]
            execution_chain.append({
                "role": role,
                "model": agent.model,
                "output": current_context
            })
            
            self._log_step("sequential_step_completed", {
                "role": role,
                "step": len(execution_chain),
                "output_length": len(current_context)
            })
        
        return current_context
    
    async def _run_iterative_improvement(self, user_prompt: str, plan: str) -> str:
        """
        Iterative improvement: Generate solution, critique, improve, repeat
        """
        max_iterations = 3
        current_solution = ""
        
        # Get primary agent (usually coder or creative_writer)
        primary_agent = self._get_primary_agent()
        critic_agent = self.agents.get("critic") or primary_agent
        
        for iteration in range(max_iterations):
            self._log_step("iteration_started", {"iteration": iteration + 1})
            
            # Generate or improve solution
            if iteration == 0:
                # Initial generation
                result = await self._execute_agent(
                    primary_agent, user_prompt, plan, f"iterative_initial"
                )
            else:
                # Improvement based on previous critique
                improvement_prompt = self._build_improvement_prompt(
                    user_prompt, current_solution, previous_critique
                )
                result = await self._call_ai_model(
                    model=primary_agent.model,
                    messages=[{"role": "system", "content": improvement_prompt}],
                    context=f"iterative_improvement_{iteration}"
                )
            
            current_solution = result["content"]
            
            # Get critique for next iteration (except on last iteration)
            if iteration < max_iterations - 1:
                critique_prompt = self._build_critique_prompt(user_prompt, current_solution)
                critique_result = await self._call_ai_model(
                    model=critic_agent.model,
                    messages=[{"role": "system", "content": critique_prompt}],
                    context=f"iterative_critique_{iteration}"
                )
                previous_critique = critique_result["content"]
                
                # Check if solution is good enough to stop early
                if "excellent" in previous_critique.lower() or "perfect" in previous_critique.lower():
                    self._log_step("early_termination", {"iteration": iteration + 1})
                    break
        
        return current_solution
    
    async def _run_pair_programming(self, user_prompt: str, plan: str) -> str:
        """
        Pair programming: Two agents work closely together
        """
        # Get coder and critic agents
        coder_agent = self.agents.get("coder") or self._get_primary_agent()
        critic_agent = self.agents.get("critic") or list(self.agents.values())[1]
        
        # Initial code generation
        code_result = await self._execute_agent(
            coder_agent, user_prompt, plan, "pair_initial_code"
        )
        current_code = code_result["content"]
        
        # Iterative improvement through pair collaboration
        for round_num in range(2):  # 2 rounds of collaboration
            # Critic reviews and suggests improvements
            review_prompt = self._build_pair_review_prompt(user_prompt, current_code)
            review_result = await self._call_ai_model(
                model=critic_agent.model,
                messages=[{"role": "system", "content": review_prompt}],
                context=f"pair_review_{round_num}"
            )
            
            # Coder implements improvements
            improvement_prompt = self._build_pair_improvement_prompt(
                user_prompt, current_code, review_result["content"]
            )
            improvement_result = await self._call_ai_model(
                model=coder_agent.model,
                messages=[{"role": "system", "content": improvement_prompt}],
                context=f"pair_improvement_{round_num}"
            )
            
            current_code = improvement_result["content"]
        
        return current_code
    
    async def _execute_agent(self, agent: TeamAgent, user_prompt: str, plan: str, context: str) -> Dict[str, Any]:
        """
        Execute a specific agent with the given context
        """
        agent_prompt = self._build_agent_prompt(agent, user_prompt, plan)
        
        return await self._call_ai_model(
            model=agent.model,
            messages=[{"role": "system", "content": agent_prompt}],
            context=context,
            temperature=agent.temperature / 100.0,
            max_tokens=agent.max_tokens
        )
    
    async def _call_ai_model(self, model: str, messages: List[Dict], context: str, 
                           temperature: float = 0.7, max_tokens: int = 2000) -> Dict[str, Any]:
        """
        Call an AI model and track usage/costs
        """
        start_time = time.time()
        
        try:
            # Use OpenAI client (can be extended to support other providers)
            client = openai.AsyncOpenAI()
            
            response = await client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            # Extract response data
            content = response.choices[0].message.content
            tokens_used = response.usage.total_tokens
            
            # Calculate cost (simplified - would use actual pricing in production)
            cost_cents = self._calculate_cost(model, tokens_used)
            
            # Update totals
            self.total_tokens_used += tokens_used
            self.total_cost_cents += cost_cents
            
            # Check cost limits
            if self.total_cost_cents > self.max_cost_cents:
                raise Exception(f"Cost limit exceeded: {self.total_cost_cents} > {self.max_cost_cents} cents")
            
            execution_time = time.time() - start_time
            
            self._log_step("ai_call_completed", {
                "model": model,
                "context": context,
                "tokens": tokens_used,
                "cost_cents": cost_cents,
                "execution_time": execution_time
            })
            
            return {
                "content": content,
                "tokens": tokens_used,
                "cost_cents": cost_cents,
                "execution_time": execution_time
            }
            
        except Exception as e:
            self._log_step("ai_call_failed", {
                "model": model,
                "context": context,
                "error": str(e)
            })
            raise
    
    def _calculate_cost(self, model: str, tokens: int) -> int:
        """
        Calculate cost in cents for model usage
        Simplified pricing - would use actual pricing in production
        """
        # Simplified pricing per 1K tokens (in cents)
        pricing = {
            "gpt-4o": 3,
            "gpt-4o-mini": 0.15,
            "claude-3.5-sonnet": 3,
            "gemini-1.5-pro": 2.5
        }
        
        base_cost = pricing.get(model, 2)  # Default cost
        return int((tokens / 1000) * base_cost)
    
    def _build_planning_prompt(self, user_prompt: str) -> str:
        """Build the initial planning prompt for the orchestrator"""
        return f"""You are an AI team orchestrator. Your job is to create a detailed execution plan for the following user request:

USER REQUEST: {user_prompt}

AVAILABLE TEAM MEMBERS:
{self._format_team_members()}

COLLABORATION STRATEGY: {self.collaboration_strategy}
COST PREFERENCE: {self.cost_preference}
AVAILABLE TOOLS: {', '.join(self.tools) if self.tools else 'None'}

Create a comprehensive plan that:
1. Breaks down the user's request into specific tasks
2. Assigns appropriate team members to each task
3. Defines the execution order and dependencies
4. Considers the collaboration strategy
5. Optimizes for the specified cost preference

Provide a clear, actionable plan that the team can follow."""
    
    def _build_agent_prompt(self, agent: TeamAgent, user_prompt: str, plan: str) -> str:
        """Build a prompt for a specific agent"""
        base_prompt = agent.system_prompt or f"You are a {agent.role} AI assistant."
        
        return f"""{base_prompt}

USER REQUEST: {user_prompt}

EXECUTION PLAN: {plan}

YOUR ROLE: {agent.role}
YOUR TASK: Based on the execution plan, perform your specific role in addressing the user's request.

{f"AVAILABLE TOOLS: {', '.join(self.tools)}" if agent.can_use_tools and self.tools else ""}

Provide a detailed response that fulfills your role in the team collaboration."""
    
    def _format_team_members(self) -> str:
        """Format team members for display in prompts"""
        members = []
        for role, agent in self.agents.items():
            members.append(f"- {role.title()}: {agent.model} (Priority: {agent.priority})")
        return "\n".join(members)
    
    def _get_primary_agent(self) -> TeamAgent:
        """Get the primary agent (highest priority or first available)"""
        if not self.agents:
            raise ValueError("No agents available")
        
        # Return agent with highest priority (lowest number)
        return min(self.agents.values(), key=lambda a: a.priority)
    
    def _log_step(self, step_type: str, data: Dict[str, Any]):
        """Log an execution step"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "step_type": step_type,
            "data": data
        }
        self.execution_log.append(log_entry)
    
    # Additional prompt building methods would be implemented here
    # (critique prompts, revision prompts, synthesis prompts, etc.)
    
    async def _synthesize_results(self, user_prompt: str, agent_results: Dict[str, str], plan: str) -> Dict[str, Any]:
        """Synthesize results from multiple agents"""
        synthesis_prompt = f"""You are the AI team orchestrator. Synthesize the following results from your team members into a comprehensive, coherent response to the user's request.

USER REQUEST: {user_prompt}
ORIGINAL PLAN: {plan}

TEAM RESULTS:
{self._format_agent_results(agent_results)}

Create a unified response that:
1. Integrates the best insights from each team member
2. Resolves any conflicts or contradictions
3. Provides a complete answer to the user's request
4. Maintains clarity and coherence

Provide the final synthesized response."""
        
        return await self._call_ai_model(
            model=self.orchestrator_model,
            messages=[{"role": "system", "content": synthesis_prompt}],
            context="final_synthesis"
        )
    
    def _format_agent_results(self, results: Dict[str, str]) -> str:
        """Format agent results for synthesis"""
        formatted = []
        for role, result in results.items():
            formatted.append(f"\n{role.upper()} RESULT:\n{result}\n")
        return "\n".join(formatted)


class ToolManager:
    """
    Manages tool execution for AI agents
    """
    
    def __init__(self):
        self.available_tools = {
            "web_search": self._web_search,
            "code_interpreter": self._code_interpreter,
            "file_read": self._file_read,
            "file_write": self._file_write,
            # Mindy AI Studio tools
            "dexinity_generate_image": self._dexinity_generate_image,
            "dexinity_generate_video": self._dexinity_generate_video,
            "dexinity_magic_resize": self._dexinity_magic_resize,
            "dexinity_sketch_to_mockup": self._dexinity_sketch_to_mockup
        }
        
        # Initialize Mindy tool manager
        self.dexinity_manager = DexinityToolManager()
    
    async def execute_tool(self, tool_name: str, **kwargs) -> Any:
        """Execute a tool with given parameters"""
        if tool_name not in self.available_tools:
            raise ValueError(f"Tool '{tool_name}' is not available.")
        
        return await self.available_tools[tool_name](**kwargs)
    
    async def _web_search(self, query: str) -> str:
        """Perform web search (mock implementation)"""
        # In production, this would integrate with actual search APIs
        return f"Search results for '{query}': [Mock search results would appear here]"
    
    async def _code_interpreter(self, code: str, language: str = "python") -> str:
        """Execute code in sandboxed environment (mock implementation)"""
        # In production, this would execute code safely
        return f"Executed {language} code:\n{code}\n\nOutput: [Mock execution output]"
    
    async def _file_read(self, path: str) -> str:
        """Read file content (mock implementation)"""
        return f"Content of file '{path}': [Mock file content]"
    
    async def _file_write(self, path: str, content: str) -> str:
        """Write file content (mock implementation)"""
        return f"Successfully wrote to file '{path}': {len(content)} characters"
    
    # Mindy AI Studio tool wrappers
    async def _dexinity_generate_image(self, prompt: str, style: str = None, brand_assets: List[str] = None) -> Dict[str, Any]:
        """Generate image using Mindy AI Studio"""
        return await self.dexinity_manager.execute_tool("dexinity_generate_image", 
                                                   prompt=prompt, 
                                                   style=style, 
                                                   brand_assets=brand_assets)
    
    async def _dexinity_generate_video(self, prompt: str, duration: int = 30, style: str = None) -> Dict[str, Any]:
        """Generate video using Mindy AI Studio"""
        return await self.dexinity_manager.execute_tool("dexinity_generate_video", 
                                                   prompt=prompt, 
                                                   duration=duration, 
                                                   style=style)
    
    async def _dexinity_magic_resize(self, image_url: str, platform: str) -> Dict[str, Any]:
        """Resize image for social media platform using Mindy"""
        return await self.dexinity_manager.execute_tool("dexinity_magic_resize", 
                                                   image_url=image_url, 
                                                   platform=platform)
    
    async def _dexinity_sketch_to_mockup(self, sketch_url: str, description: str = None) -> Dict[str, Any]:
        """Convert sketch to mockup using Mindy"""
        return await self.dexinity_manager.execute_tool("dexinity_sketch_to_mockup", 
                                                   sketch_url=sketch_url, 
                                                   description=description)
    
    def get_available_tools(self) -> List[str]:
        """Get list of available tool names"""
        return list(self.available_tools.keys())
    
    def get_dexinity_tools(self) -> List[Dict[str, Any]]:
        """Get detailed information about Mindy tools"""
        return self.dexinity_manager.get_available_tools()

