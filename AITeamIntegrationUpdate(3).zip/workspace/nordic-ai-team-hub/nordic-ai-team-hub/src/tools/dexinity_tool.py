"""
Dexinity AI Studio Tool Integration for NordicAI Hub
Provides image and video generation capabilities through Dexinity AI Studio
"""

import asyncio
import json
import time
from typing import Dict, Any, Optional, List
import requests
from slack_sdk.web.async_client import AsyncWebClient
from slack_sdk.errors import SlackApiError

class DexinityTool:
    """
    Tool for integrating Dexinity AI Studio capabilities into AI team workflows
    """
    
    def __init__(self, slack_token: str = None, workspace_id: str = None, channel_id: str = None):
        """
        Initialize Dexinity tool with Slack integration
        
        Args:
            slack_token: Slack bot token for API access
            workspace_id: Slack workspace ID where Dexinity is installed
            channel_id: Channel ID for Dexinity communication
        """
        self.slack_token = slack_token
        self.workspace_id = workspace_id
        self.channel_id = channel_id or "dexinity-ai-hub"  # Default channel
        
        if slack_token:
            self.slack_client = AsyncWebClient(token=slack_token)
        else:
            self.slack_client = None
            
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 2  # Minimum 2 seconds between requests
        
        # Mock mode for development/testing
        self.mock_mode = not bool(slack_token)
    
    async def generate_image(self, prompt: str, style: str = None, brand_assets: List[str] = None) -> Dict[str, Any]:
        """
        Generate an image using Dexinity AI Studio
        
        Args:
            prompt: Description of the image to generate
            style: Optional style specification
            brand_assets: Optional list of brand asset URLs to maintain consistency
            
        Returns:
            Dict containing image URL and metadata
        """
        if self.mock_mode:
            return await self._mock_generate_image(prompt, style)
        
        try:
            # Rate limiting
            await self._rate_limit()
            
            # Construct Dexinity command
            dexinity_command = f"@Dexinity create an image: {prompt}"
            if style:
                dexinity_command += f" in {style} style"
            
            # Send command to Slack channel
            response = await self.slack_client.chat_postMessage(
                channel=self.channel_id,
                text=dexinity_command
            )
            
            # Wait for Dexinity's response
            image_result = await self._wait_for_dexinity_response(response['ts'])
            
            return {
                "success": True,
                "image_url": image_result.get("image_url"),
                "prompt": prompt,
                "style": style,
                "generation_time": image_result.get("generation_time", 0),
                "cost_estimate": self._estimate_cost("image"),
                "metadata": {
                    "tool": "dexinity",
                    "type": "image_generation",
                    "slack_message_id": response['ts']
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "prompt": prompt,
                "tool": "dexinity"
            }
    
    async def generate_video(self, prompt: str, duration: int = 30, style: str = None) -> Dict[str, Any]:
        """
        Generate a video using Dexinity AI Studio
        
        Args:
            prompt: Description of the video to generate
            duration: Video duration in seconds (default 30)
            style: Optional style specification
            
        Returns:
            Dict containing video URL and metadata
        """
        if self.mock_mode:
            return await self._mock_generate_video(prompt, duration)
        
        try:
            # Rate limiting
            await self._rate_limit()
            
            # Construct Dexinity command
            dexinity_command = f"@Dexinity create a {duration}-second video: {prompt}"
            if style:
                dexinity_command += f" in {style} style"
            
            # Send command to Slack channel
            response = await self.slack_client.chat_postMessage(
                channel=self.channel_id,
                text=dexinity_command
            )
            
            # Wait for Dexinity's response (videos take longer)
            video_result = await self._wait_for_dexinity_response(response['ts'], timeout=120)
            
            return {
                "success": True,
                "video_url": video_result.get("video_url"),
                "prompt": prompt,
                "duration": duration,
                "style": style,
                "generation_time": video_result.get("generation_time", 0),
                "cost_estimate": self._estimate_cost("video"),
                "metadata": {
                    "tool": "dexinity",
                    "type": "video_generation",
                    "slack_message_id": response['ts']
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "prompt": prompt,
                "tool": "dexinity"
            }
    
    async def magic_resize(self, image_url: str, platform: str) -> Dict[str, Any]:
        """
        Resize image for specific social media platform using Dexinity's Magic Resize
        
        Args:
            image_url: URL of the image to resize
            platform: Target platform (instagram, facebook, twitter, linkedin, etc.)
            
        Returns:
            Dict containing resized image URL and metadata
        """
        if self.mock_mode:
            return await self._mock_magic_resize(image_url, platform)
        
        try:
            # Rate limiting
            await self._rate_limit()
            
            # Upload image to Slack first (if it's not already there)
            # Then use Dexinity's Magic Resize feature
            dexinity_command = f"@Dexinity resize this image for {platform}"
            
            # Send command with image attachment
            response = await self.slack_client.chat_postMessage(
                channel=self.channel_id,
                text=dexinity_command,
                attachments=[{
                    "image_url": image_url,
                    "fallback": "Image to resize"
                }]
            )
            
            # Wait for Dexinity's response
            resize_result = await self._wait_for_dexinity_response(response['ts'])
            
            return {
                "success": True,
                "resized_image_url": resize_result.get("image_url"),
                "original_image_url": image_url,
                "platform": platform,
                "generation_time": resize_result.get("generation_time", 0),
                "cost_estimate": self._estimate_cost("resize"),
                "metadata": {
                    "tool": "dexinity",
                    "type": "magic_resize",
                    "slack_message_id": response['ts']
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "image_url": image_url,
                "platform": platform,
                "tool": "dexinity"
            }
    
    async def sketch_to_mockup(self, sketch_url: str, description: str = None) -> Dict[str, Any]:
        """
        Convert a sketch or wireframe to a polished mockup using Dexinity
        
        Args:
            sketch_url: URL of the sketch/wireframe image
            description: Optional description of desired output
            
        Returns:
            Dict containing mockup URL and metadata
        """
        if self.mock_mode:
            return await self._mock_sketch_to_mockup(sketch_url, description)
        
        try:
            # Rate limiting
            await self._rate_limit()
            
            # Construct Dexinity command
            dexinity_command = "@Dexinity convert this sketch to a polished mockup"
            if description:
                dexinity_command += f": {description}"
            
            # Send command with sketch attachment
            response = await self.slack_client.chat_postMessage(
                channel=self.channel_id,
                text=dexinity_command,
                attachments=[{
                    "image_url": sketch_url,
                    "fallback": "Sketch to convert"
                }]
            )
            
            # Wait for Dexinity's response
            mockup_result = await self._wait_for_dexinity_response(response['ts'])
            
            return {
                "success": True,
                "mockup_url": mockup_result.get("image_url"),
                "original_sketch_url": sketch_url,
                "description": description,
                "generation_time": mockup_result.get("generation_time", 0),
                "cost_estimate": self._estimate_cost("mockup"),
                "metadata": {
                    "tool": "dexinity",
                    "type": "sketch_to_mockup",
                    "slack_message_id": response['ts']
                }
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "sketch_url": sketch_url,
                "tool": "dexinity"
            }
    
    async def _wait_for_dexinity_response(self, original_message_ts: str, timeout: int = 60) -> Dict[str, Any]:
        """
        Wait for Dexinity's response in the Slack channel
        
        Args:
            original_message_ts: Timestamp of the original message
            timeout: Maximum time to wait in seconds
            
        Returns:
            Dict containing Dexinity's response data
        """
        start_time = time.time()
        
        while time.time() - start_time < timeout:
            try:
                # Get recent messages in the channel
                response = await self.slack_client.conversations_history(
                    channel=self.channel_id,
                    oldest=original_message_ts,
                    limit=10
                )
                
                # Look for Dexinity's response
                for message in response['messages']:
                    if (message.get('user') == 'dexinity_bot_id' or  # Replace with actual Dexinity bot ID
                        'dexinity' in message.get('username', '').lower()):
                        
                        # Extract image/video URL from message
                        result = self._extract_media_from_message(message)
                        if result:
                            return result
                
                # Wait before checking again
                await asyncio.sleep(2)
                
            except SlackApiError as e:
                print(f"Slack API error while waiting for Dexinity response: {e}")
                await asyncio.sleep(2)
        
        # Timeout reached
        raise TimeoutError(f"Dexinity did not respond within {timeout} seconds")
    
    def _extract_media_from_message(self, message: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Extract media URLs from Dexinity's Slack message
        
        Args:
            message: Slack message object
            
        Returns:
            Dict containing extracted media URL and metadata
        """
        # Check for file attachments
        if 'files' in message:
            for file in message['files']:
                if file.get('mimetype', '').startswith(('image/', 'video/')):
                    return {
                        "image_url": file.get('url_private') if 'image' in file.get('mimetype', '') else None,
                        "video_url": file.get('url_private') if 'video' in file.get('mimetype', '') else None,
                        "generation_time": time.time() - self.last_request_time,
                        "file_size": file.get('size'),
                        "file_type": file.get('mimetype')
                    }
        
        # Check for image attachments in message
        if 'attachments' in message:
            for attachment in message['attachments']:
                if 'image_url' in attachment:
                    return {
                        "image_url": attachment['image_url'],
                        "generation_time": time.time() - self.last_request_time
                    }
        
        return None
    
    async def _rate_limit(self):
        """Apply rate limiting between requests"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            await asyncio.sleep(self.min_request_interval - time_since_last)
        
        self.last_request_time = time.time()
    
    def _estimate_cost(self, operation_type: str) -> Dict[str, Any]:
        """
        Estimate cost for Dexinity operations based on pricing tiers
        
        Args:
            operation_type: Type of operation (image, video, resize, mockup)
            
        Returns:
            Dict containing cost estimates
        """
        # Based on Dexinity's pricing: Starter $29/month for 100 images + 20 videos
        cost_per_image = 29 / 100  # $0.29 per image
        cost_per_video = 29 / 20   # $1.45 per video
        
        costs = {
            "image": cost_per_image,
            "video": cost_per_video,
            "resize": cost_per_image * 0.5,  # Assume resize costs less
            "mockup": cost_per_image * 1.2   # Assume mockup costs slightly more
        }
        
        return {
            "estimated_cost_usd": costs.get(operation_type, cost_per_image),
            "currency": "USD",
            "pricing_tier": "starter",
            "operation_type": operation_type
        }
    
    # Mock methods for development/testing
    async def _mock_generate_image(self, prompt: str, style: str = None) -> Dict[str, Any]:
        """Mock image generation for testing"""
        await asyncio.sleep(2)  # Simulate generation time
        return {
            "success": True,
            "image_url": f"https://mock-dexinity.com/images/generated_{hash(prompt) % 10000}.jpg",
            "prompt": prompt,
            "style": style,
            "generation_time": 2.0,
            "cost_estimate": self._estimate_cost("image"),
            "metadata": {
                "tool": "dexinity",
                "type": "image_generation",
                "mock": True
            }
        }
    
    async def _mock_generate_video(self, prompt: str, duration: int) -> Dict[str, Any]:
        """Mock video generation for testing"""
        await asyncio.sleep(5)  # Simulate longer generation time
        return {
            "success": True,
            "video_url": f"https://mock-dexinity.com/videos/generated_{hash(prompt) % 10000}.mp4",
            "prompt": prompt,
            "duration": duration,
            "generation_time": 5.0,
            "cost_estimate": self._estimate_cost("video"),
            "metadata": {
                "tool": "dexinity",
                "type": "video_generation",
                "mock": True
            }
        }
    
    async def _mock_magic_resize(self, image_url: str, platform: str) -> Dict[str, Any]:
        """Mock magic resize for testing"""
        await asyncio.sleep(1)
        return {
            "success": True,
            "resized_image_url": f"https://mock-dexinity.com/resized/{platform}_{hash(image_url) % 10000}.jpg",
            "original_image_url": image_url,
            "platform": platform,
            "generation_time": 1.0,
            "cost_estimate": self._estimate_cost("resize"),
            "metadata": {
                "tool": "dexinity",
                "type": "magic_resize",
                "mock": True
            }
        }
    
    async def _mock_sketch_to_mockup(self, sketch_url: str, description: str = None) -> Dict[str, Any]:
        """Mock sketch to mockup for testing"""
        await asyncio.sleep(3)
        return {
            "success": True,
            "mockup_url": f"https://mock-dexinity.com/mockups/converted_{hash(sketch_url) % 10000}.jpg",
            "original_sketch_url": sketch_url,
            "description": description,
            "generation_time": 3.0,
            "cost_estimate": self._estimate_cost("mockup"),
            "metadata": {
                "tool": "dexinity",
                "type": "sketch_to_mockup",
                "mock": True
            }
        }


class DexinityToolManager:
    """
    Manager class for Dexinity tool integration in team orchestrator
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize Dexinity tool manager
        
        Args:
            config: Configuration dict containing Slack credentials and settings
        """
        self.config = config or {}
        self.dexinity_tool = DexinityTool(
            slack_token=self.config.get('slack_token'),
            workspace_id=self.config.get('workspace_id'),
            channel_id=self.config.get('channel_id')
        )
    
    async def execute_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """
        Execute a Dexinity tool operation
        
        Args:
            tool_name: Name of the tool operation
            **kwargs: Tool-specific arguments
            
        Returns:
            Dict containing operation results
        """
        tool_map = {
            "dexinity_generate_image": self.dexinity_tool.generate_image,
            "dexinity_generate_video": self.dexinity_tool.generate_video,
            "dexinity_magic_resize": self.dexinity_tool.magic_resize,
            "dexinity_sketch_to_mockup": self.dexinity_tool.sketch_to_mockup
        }
        
        if tool_name not in tool_map:
            return {
                "success": False,
                "error": f"Unknown Dexinity tool: {tool_name}",
                "available_tools": list(tool_map.keys())
            }
        
        try:
            result = await tool_map[tool_name](**kwargs)
            return result
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "tool": tool_name,
                "kwargs": kwargs
            }
    
    def get_available_tools(self) -> List[Dict[str, Any]]:
        """
        Get list of available Dexinity tools with descriptions
        
        Returns:
            List of tool descriptions
        """
        return [
            {
                "name": "dexinity_generate_image",
                "description": "Generate images using Dexinity AI Studio",
                "parameters": ["prompt", "style", "brand_assets"],
                "cost_estimate": "$0.29 per image"
            },
            {
                "name": "dexinity_generate_video",
                "description": "Generate short videos using Dexinity AI Studio",
                "parameters": ["prompt", "duration", "style"],
                "cost_estimate": "$1.45 per video"
            },
            {
                "name": "dexinity_magic_resize",
                "description": "Resize images for social media platforms",
                "parameters": ["image_url", "platform"],
                "cost_estimate": "$0.15 per resize"
            },
            {
                "name": "dexinity_sketch_to_mockup",
                "description": "Convert sketches to polished mockups",
                "parameters": ["sketch_url", "description"],
                "cost_estimate": "$0.35 per conversion"
            }
        ]

