// Dexinity API types

// Image generation settings
export interface DexinityImageSettings {
  style: 'realistic' | 'artistic' | 'cartoon' | 'anime';
  ratio: '1:1' | '16:9' | '9:16' | '4:3';
  numberOfImages: number;
  creativityLevel: number;
  negativePrompt: string;
}

// Video generation settings
export interface DexinityVideoSettings {
  duration: number;
  style: 'cinematic' | 'animation' | 'stylized' | 'realistic';
  addAudio: boolean;
}

// Sketch to mockup settings
export interface DexinitySketchSettings {
  outputStyle: 'wireframe' | 'ui' | 'mobile' | 'web';
  fidelity: 'low' | 'medium' | 'high';
  maintainColors: boolean;
}

// Magic resize settings
export interface DexinityResizeSettings {
  platforms: {
    instagram_post?: boolean;
    instagram_story?: boolean;
    facebook_post?: boolean;
    twitter_post?: boolean;
    linkedin_post?: boolean;
    youtube_thumbnail?: boolean;
  };
  customSize?: {
    width: number;
    height: number;
  };
  contentPreservation: number;
}

// Generated image result
export interface DexinityGeneratedImage {
  id: string;
  url: string;
  prompt: string;
  settings: DexinityImageSettings;
  created_at: Date;
}

// Generated video result
export interface DexinityGeneratedVideo {
  id: string;
  url: string;
  thumbnail_url: string;
  prompt: string;
  settings: DexinityVideoSettings;
  duration: number;
  created_at: Date;
}

// Mockup conversion result
export interface DexinityMockupResult {
  id: string;
  original_url: string;
  mockup_url: string;
  settings: DexinitySketchSettings;
  created_at: Date;
}

// Magic resize result
export interface DexinityResizeResult {
  id: string;
  original_url: string;
  resized_images: {
    platform: string;
    url: string;
    width: number;
    height: number;
  }[];
  settings: DexinityResizeSettings;
  created_at: Date;
}