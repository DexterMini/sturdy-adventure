// Team and AI Models types

// Available collaboration strategies
export type CollaborationStrategy = 'sequential' | 'parallel' | 'hierarchical' | 'adaptive';

// Team member configuration
export interface TeamMember {
  id: string;
  role: string;
  model: string;
  parameters: Record<string, unknown>;
}

// AI Team configuration
export interface AITeam {
  id: string;
  name: string;
  description: string;
  members: TeamMember[];
  strategy: CollaborationStrategy;
  active: boolean;
  created_at: Date;
  updated_at: Date;
}

// AI Model information
export interface AIModel {
  id: string;
  name: string;
  provider: string;
  description: string;
  cost_per_1k_tokens: number;
  suitable_roles: string[];
}

// Team chat message
export interface TeamChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

// Team collaboration history entry
export interface CollaborationHistoryEntry {
  id: string;
  team_id: string;
  prompt: string;
  response: string;
  strategy: CollaborationStrategy;
  member_contributions: {
    member_id: string;
    role: string;
    model: string;
    input: string;
    output: string;
    tokens_used: number;
  }[];
  total_tokens: number;
  total_cost: number;
  duration_ms: number;
  timestamp: Date;
}