import { Toaster } from '@/components/ui/sonner';
import { TooltipProvider } from '@/components/ui/tooltip';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainLayout from '@/components/layout/MainLayout';
import { Suspense, lazy } from 'react';
import { NotFound } from '@/pages';
import { ThemeProvider } from '@/hooks/use-theme';

// Lazy load pages for better performance
const ChatPage = lazy(() => import('./pages/ChatPage'));
const ModelsPage = lazy(() => import('./pages/ModelsPage'));
const PricingPage = lazy(() => import('./pages/PricingPage'));
const TeamPage = lazy(() => import('./pages/TeamPage'));
const DexinityPage = lazy(() => import('./pages/DexinityPage'));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="system" storageKey="nordic-ai-theme">
      <TooltipProvider>
        <Toaster />
        <BrowserRouter>
          <MainLayout>
            <Suspense fallback={<div className="p-12 text-center">Loading...</div>}>
              <Routes>
                <Route path="/" element={<ChatPage />} />
                <Route path="/models" element={<ModelsPage />} />
                <Route path="/pricing" element={<PricingPage />} />
                <Route path="/team" element={<TeamPage />} />
                <Route path="/dexinity" element={<DexinityPage />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </Suspense>
          </MainLayout>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;