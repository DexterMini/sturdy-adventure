import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { MoonIcon, SunIcon } from '@radix-ui/react-icons';
import { useTheme } from '@/hooks/use-theme';
import { 
  MessageSquare,
  Users,
  Layers,
  CreditCard,
  Image,
  Menu,
  X
} from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const { theme, setTheme } = useTheme();
  const [currentTab, setCurrentTab] = useState('chat');
  const [isMobile, setIsMobile] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  // Determine the current tab based on URL path
  useEffect(() => {
    const path = location.pathname.split('/')[1] || 'chat';
    setCurrentTab(path);
  }, [location.pathname]);

  // Handle responsive layout
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', checkScreenSize);
    checkScreenSize();
    
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // Handle tab change
  const handleTabChange = (value: string) => {
    setCurrentTab(value);
    navigate(value === 'chat' ? '/' : `/${value}`);
    if (isMobile) setIsOpen(false);
  };

  const tabs = [
    { value: 'chat', label: 'Chat', icon: <MessageSquare className="h-4 w-4 mr-2" /> },
    { value: 'team', label: 'Team', icon: <Users className="h-4 w-4 mr-2" /> },
    { value: 'models', label: 'Models', icon: <Layers className="h-4 w-4 mr-2" /> },
    { value: 'pricing', label: 'Pricing', icon: <CreditCard className="h-4 w-4 mr-2" /> },
    { value: 'dexinity', label: 'Dexinity', icon: <Image className="h-4 w-4 mr-2" /> },
  ];

  const renderTabs = () => (
    <Tabs value={currentTab} className="w-full" onValueChange={handleTabChange}>
      <TabsList className="grid w-full grid-cols-5">
        {tabs.map((tab) => (
          <TabsTrigger key={tab.value} value={tab.value} className="flex items-center">
            {!isMobile && tab.icon}
            <span>{tab.label}</span>
          </TabsTrigger>
        ))}
      </TabsList>
      {children}
    </Tabs>
  );

  const renderMobileNav = () => (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[250px] sm:w-[300px]">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between py-4">
            <h2 className="text-lg font-semibold">Nordic AI Team Hub</h2>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>
          <nav className="space-y-2 py-4">
            {tabs.map((tab) => (
              <Button
                key={tab.value}
                variant={currentTab === tab.value ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => handleTabChange(tab.value)}
              >
                {tab.icon}
                {tab.label}
              </Button>
            ))}
          </nav>
          <div className="mt-auto py-4">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            >
              {theme === "dark" ? <SunIcon /> : <MoonIcon />}
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="flex items-center gap-2">
            {isMobile && renderMobileNav()}
            <Link to="/" className="flex items-center gap-2">
              <span className="font-bold text-lg">Nordic AI Team Hub</span>
            </Link>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="hidden md:flex"
            >
              {theme === "dark" ? <SunIcon className="h-4 w-4" /> : <MoonIcon className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container py-6">
        {renderTabs()}
      </main>

      {/* Footer */}
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-14 md:flex-row">
          <p className="text-center text-sm text-muted-foreground md:text-left">
            &copy; {new Date().getFullYear()} Nordic AI Team Hub. All rights reserved.
          </p>
          <p className="text-center text-sm text-muted-foreground md:text-right">
            Built with <a href="https://react.dev/" className="underline">React</a> and <a href="https://ui.shadcn.com/" className="underline">shadcn/ui</a>
          </p>
        </div>
      </footer>
    </div>
  );
}