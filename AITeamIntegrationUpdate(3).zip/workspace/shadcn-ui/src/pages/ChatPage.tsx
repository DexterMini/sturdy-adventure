import { useState } from 'react';
import { TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Send, User, Bot } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar } from '@/components/ui/avatar';
import { teamApi } from '@/lib/api';
import { useMutation } from '@tanstack/react-query';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Hello! I am your Nordic AI assistant. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  
  const [inputMessage, setInputMessage] = useState('');

  // Mutation for sending chat message
  const chatMutation = useMutation({
    mutationFn: (message: string) => teamApi.teamChatCompletions(message),
    onSuccess: (data) => {
      if (data.success && data.result) {
        addMessage('assistant', data.result);
      } else {
        addMessage('assistant', data.error || 'Sorry, I encountered an error processing your request.');
      }
    },
    onError: (error) => {
      addMessage(
        'assistant', 
        `Sorry, I encountered an error: ${error instanceof Error ? error.message : 'Unknown error'}`
      );
    }
  });

  const addMessage = (role: 'user' | 'assistant', content: string) => {
    setMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        role,
        content,
        timestamp: new Date()
      }
    ]);
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;
    
    // Add user message to chat
    addMessage('user', inputMessage);
    
    // Send to API
    chatMutation.mutate(inputMessage);
    
    // Clear input
    setInputMessage('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <TabsContent value="chat" className="space-y-4">
      <Card className="h-[calc(100vh-12rem)]">
        <CardHeader>
          <CardTitle>AI Assistant</CardTitle>
        </CardHeader>
        
        <CardContent className="p-0">
          <ScrollArea className="h-[calc(100vh-18rem)] px-4">
            <div className="space-y-4 pt-2 pb-4">
              {messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div 
                    className={`flex gap-3 max-w-[80%] ${
                      msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'
                    }`}
                  >
                    <Avatar className={msg.role === 'user' ? 'bg-primary' : 'bg-muted'}>
                      {msg.role === 'user' ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
                    </Avatar>
                    <div 
                      className={`rounded-lg p-3 text-sm ${
                        msg.role === 'user' 
                          ? 'bg-primary text-primary-foreground' 
                          : 'bg-muted text-secondary-foreground'
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{msg.content}</div>
                      <div className="mt-1 text-xs opacity-70">
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {chatMutation.isPending && (
                <div className="flex justify-start">
                  <div className="flex gap-3">
                    <Avatar className="bg-muted">
                      <Bot className="h-5 w-5" />
                    </Avatar>
                    <div className="rounded-lg p-3 text-sm bg-muted text-secondary-foreground flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Thinking...
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
        
        <CardFooter className="border-t p-3">
          <div className="flex w-full items-center gap-2">
            <Textarea
              placeholder="Type your message..."
              className="min-h-10 flex-1"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={handleKeyDown}
            />
            <Button 
              size="icon" 
              onClick={handleSendMessage}
              disabled={chatMutation.isPending || !inputMessage.trim()}
            >
              {chatMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </TabsContent>
  );
}