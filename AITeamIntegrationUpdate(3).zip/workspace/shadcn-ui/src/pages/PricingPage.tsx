import { TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, XCircle } from 'lucide-react';

export default function PricingPage() {
  return (
    <TabsContent value="pricing" className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Pricing</h2>
        <p className="text-muted-foreground">
          View pricing information for AI teams and Dexinity services
        </p>
      </div>

      <Tabs defaultValue="teams" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="teams">AI Teams</TabsTrigger>
          <TabsTrigger value="dexinity">Dexinity Services</TabsTrigger>
        </TabsList>
        
        {/* Team Pricing */}
        <TabsContent value="teams" className="space-y-4 pt-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Basic Tier */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  Basic
                  <Badge>Popular</Badge>
                </CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">$29</span>
                  <span className="text-muted-foreground"> / month</span>
                </div>
                <CardDescription>
                  For individual users and small projects
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Up to 5 team configurations
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Basic models (GPT-3.5, Claude Instant)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    50 team collaboration requests per day
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Sequential collaboration strategy
                  </li>
                  <li className="flex items-center gap-2">
                    <XCircle className="h-4 w-4 text-red-500" />
                    Advanced models
                  </li>
                  <li className="flex items-center gap-2">
                    <XCircle className="h-4 w-4 text-red-500" />
                    Parallel processing
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <p className="text-xs text-muted-foreground">
                  Maximum cost cap of $5 per day included
                </p>
              </CardFooter>
            </Card>

            {/* Professional Tier */}
            <Card className="border-2 border-primary">
              <CardHeader>
                <CardTitle className="flex justify-between items-center">
                  Professional
                  <Badge variant="default">Recommended</Badge>
                </CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">$79</span>
                  <span className="text-muted-foreground"> / month</span>
                </div>
                <CardDescription>
                  For professionals and growing businesses
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Unlimited team configurations
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Advanced models (GPT-4, Claude 2)
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    200 team collaboration requests per day
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Sequential and parallel strategies
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Team history and analytics
                  </li>
                  <li className="flex items-center gap-2">
                    <XCircle className="h-4 w-4 text-red-500" />
                    Enterprise support
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <p className="text-xs text-muted-foreground">
                  Maximum cost cap of $20 per day included
                </p>
              </CardFooter>
            </Card>

            {/* Enterprise Tier */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle>Enterprise</CardTitle>
                <div className="mt-2">
                  <span className="text-3xl font-bold">Custom</span>
                </div>
                <CardDescription>
                  For large organizations with custom needs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Everything in Professional tier
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Custom model deployments
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Unlimited requests
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    All collaboration strategies
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    Dedicated account manager
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                    24/7 priority support
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <p className="text-xs text-muted-foreground">
                  Custom cost caps and billing options available
                </p>
              </CardFooter>
            </Card>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Team Collaboration Strategies</CardTitle>
              <CardDescription>
                Compare different collaboration approaches for AI teams
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Strategy</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Best For</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Cost</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Sequential</TableCell>
                    <TableCell>Agents work one after another, passing results to the next agent</TableCell>
                    <TableCell>Linear workflows, step-by-step processes</TableCell>
                    <TableCell>Slower</TableCell>
                    <TableCell>Lower</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Parallel</TableCell>
                    <TableCell>Multiple agents work simultaneously on the same task</TableCell>
                    <TableCell>Brainstorming, diverse perspectives</TableCell>
                    <TableCell>Faster</TableCell>
                    <TableCell>Higher</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Hierarchical</TableCell>
                    <TableCell>Manager agents coordinate specialist agents</TableCell>
                    <TableCell>Complex projects, delegation</TableCell>
                    <TableCell>Medium</TableCell>
                    <TableCell>Medium</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Adaptive</TableCell>
                    <TableCell>Dynamic strategy selection based on task requirements</TableCell>
                    <TableCell>Varied workloads, unpredictable tasks</TableCell>
                    <TableCell>Variable</TableCell>
                    <TableCell>Optimized</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Dexinity Pricing */}
        <TabsContent value="dexinity" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle>Dexinity AI Studio Pricing</CardTitle>
              <CardDescription>
                Service-based pricing for Dexinity creative tools
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Service</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Price</TableHead>
                    <TableHead>Unit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Image Generation</TableCell>
                    <TableCell>Create original AI-generated images from text prompts</TableCell>
                    <TableCell>$0.02 - $0.08</TableCell>
                    <TableCell>Per image</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Video Generation</TableCell>
                    <TableCell>Create short AI-generated videos from text prompts</TableCell>
                    <TableCell>$0.10 - $0.50</TableCell>
                    <TableCell>Per second</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Magic Resize</TableCell>
                    <TableCell>Auto-resize images for different social media platforms</TableCell>
                    <TableCell>$0.01 - $0.05</TableCell>
                    <TableCell>Per resize</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Sketch to Mockup</TableCell>
                    <TableCell>Convert hand-drawn sketches to polished mockups</TableCell>
                    <TableCell>$0.05 - $0.20</TableCell>
                    <TableCell>Per conversion</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </CardContent>
            <CardFooter>
              <p className="text-sm text-muted-foreground">
                Prices vary based on complexity, resolution, and selected options.
                Bulk pricing available for high-volume usage.
              </p>
            </CardFooter>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Usage Packs</CardTitle>
                <CardDescription>
                  Pre-purchased credits for Dexinity services
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 border-b pb-2">
                  <div className="flex justify-between">
                    <span>Starter Pack</span>
                    <span className="font-medium">$25</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    100 credits (~25 images or 5 minutes of video)
                  </p>
                </div>
                <div className="space-y-2 border-b pb-2">
                  <div className="flex justify-between">
                    <span>Professional Pack</span>
                    <span className="font-medium">$100</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    500 credits with 20% bonus (600 total)
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Business Pack</span>
                    <span className="font-medium">$500</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    3000 credits with 50% bonus (4500 total)
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <p className="text-xs text-muted-foreground">
                  Credits valid for 12 months from purchase date
                </p>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Subscription Plans</CardTitle>
                <CardDescription>
                  Monthly plans with reserved capacity
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 border-b pb-2">
                  <div className="flex justify-between">
                    <span>Creator</span>
                    <span className="font-medium">$49/month</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    250 credits monthly + priority queue
                  </p>
                </div>
                <div className="space-y-2 border-b pb-2">
                  <div className="flex justify-between">
                    <span>Studio</span>
                    <span className="font-medium">$199/month</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    1200 credits monthly + priority queue + brand asset storage
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Agency</span>
                    <span className="font-medium">$499/month</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    3500 credits monthly + dedicated queue + all premium features
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <p className="text-xs text-muted-foreground">
                  Annual subscriptions available with 2 months free
                </p>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </TabsContent>
  );
}