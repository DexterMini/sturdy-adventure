import { useState } from 'react';
import { TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, Plus, X, Edit, Save, Trash2, Users } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { teamApi } from '@/lib/api';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AITeam, TeamMember, CollaborationStrategy } from '@/types/team';

export default function TeamPage() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('my-teams');
  const [editingTeam, setEditingTeam] = useState<AITeam | null>(null);
  const [isCreatingTeam, setIsCreatingTeam] = useState(false);
  const [newTeam, setNewTeam] = useState<Partial<AITeam>>({
    name: '',
    description: '',
    members: [],
    strategy: 'sequential',
  });

  // Fetch teams
  const { data: teamsData, isLoading: teamsLoading, isError: teamsError } = useQuery({
    queryKey: ['teams'],
    queryFn: () => teamApi.getTeams(),
  });

  // Create team mutation
  const createTeamMutation = useMutation({
    mutationFn: (team: Partial<AITeam>) => teamApi.createTeam(team),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teams'] });
      setIsCreatingTeam(false);
      setNewTeam({
        name: '',
        description: '',
        members: [],
        strategy: 'sequential',
      });
    },
  });

  // Update team mutation
  const updateTeamMutation = useMutation({
    mutationFn: (team: AITeam) => teamApi.updateTeam(team),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teams'] });
      setEditingTeam(null);
    },
  });

  // Delete team mutation
  const deleteTeamMutation = useMutation({
    mutationFn: (teamId: string) => teamApi.deleteTeam(teamId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['teams'] });
    },
  });

  // Team members list - in a real app, fetch from API
  const availableRoles = [
    'Researcher',
    'Writer',
    'Coder',
    'Designer',
    'Manager',
    'Critic',
    'Assistant',
  ];
  
  const availableModels = [
    'gpt-4',
    'gpt-3.5-turbo',
    'claude-2',
    'claude-instant',
    'gemini-pro',
  ];

  // Handle add member to new/editing team
  const handleAddMember = (team: Partial<AITeam>) => {
    const updatedTeam = { ...team };
    updatedTeam.members = [...(updatedTeam.members || []), {
      id: `member-${Date.now()}`,
      role: '',
      model: '',
      parameters: {},
    }];
    if (team === newTeam) {
      setNewTeam(updatedTeam);
    } else if (editingTeam) {
      setEditingTeam(updatedTeam as AITeam);
    }
  };

  // Handle remove member
  const handleRemoveMember = (team: Partial<AITeam>, memberId: string) => {
    const updatedTeam = { ...team };
    updatedTeam.members = updatedTeam.members?.filter(m => m.id !== memberId) || [];
    if (team === newTeam) {
      setNewTeam(updatedTeam);
    } else if (editingTeam) {
      setEditingTeam(updatedTeam as AITeam);
    }
  };

  // Handle update member
  const handleUpdateMember = (team: Partial<AITeam>, memberId: string, field: keyof TeamMember, value: string) => {
    const updatedTeam = { ...team };
    const memberIndex = updatedTeam.members?.findIndex(m => m.id === memberId) || -1;
    
    if (memberIndex !== -1 && updatedTeam.members) {
      updatedTeam.members[memberIndex] = {
        ...updatedTeam.members[memberIndex],
        [field]: value
      };
      
      if (team === newTeam) {
        setNewTeam(updatedTeam);
      } else if (editingTeam) {
        setEditingTeam(updatedTeam as AITeam);
      }
    }
  };

  // Team card component
  const TeamCard = ({ team }: { team: AITeam }) => {
    const isEditing = editingTeam?.id === team.id;
    const currentTeam = isEditing ? editingTeam : team;

    return (
      <Card>
        <CardHeader>
          {isEditing ? (
            <Input
              value={currentTeam.name}
              onChange={(e) => setEditingTeam({ ...currentTeam, name: e.target.value })}
              className="font-semibold text-lg"
            />
          ) : (
            <CardTitle className="flex justify-between items-center">
              {team.name}
              <Badge variant={team.active ? 'default' : 'outline'}>
                {team.active ? 'Active' : 'Inactive'}
              </Badge>
            </CardTitle>
          )}
          
          {isEditing ? (
            <Input
              value={currentTeam.description}
              onChange={(e) => setEditingTeam({ ...currentTeam, description: e.target.value })}
            />
          ) : (
            <CardDescription>{team.description}</CardDescription>
          )}
        </CardHeader>
        
        <CardContent className="space-y-4">
          {isEditing ? (
            <div className="space-y-4">
              <div>
                <Label>Collaboration Strategy</Label>
                <Select
                  value={currentTeam.strategy}
                  onValueChange={(value: CollaborationStrategy) => 
                    setEditingTeam({ ...currentTeam, strategy: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select strategy" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sequential">Sequential</SelectItem>
                    <SelectItem value="parallel">Parallel</SelectItem>
                    <SelectItem value="hierarchical">Hierarchical</SelectItem>
                    <SelectItem value="adaptive">Adaptive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label>Status</Label>
                <div className="flex items-center space-x-2 mt-2">
                  <Checkbox
                    id={`active-${team.id}`}
                    checked={currentTeam.active}
                    onCheckedChange={(checked) => 
                      setEditingTeam({ ...currentTeam, active: !!checked })
                    }
                  />
                  <label
                    htmlFor={`active-${team.id}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Active
                  </label>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <Label>Team Members</Label>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleAddMember(currentTeam)}
                  >
                    <Plus className="h-4 w-4 mr-1" /> Add Member
                  </Button>
                </div>
                
                {currentTeam.members?.map((member) => (
                  <div key={member.id} className="border rounded-md p-3 mb-2">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Member</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveMember(currentTeam, member.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="grid gap-2">
                      <div className="grid grid-cols-1 gap-2">
                        <Label htmlFor={`role-${member.id}`}>Role</Label>
                        <Select
                          value={member.role}
                          onValueChange={(value) => 
                            handleUpdateMember(currentTeam, member.id, 'role', value)
                          }
                        >
                          <SelectTrigger id={`role-${member.id}`}>
                            <SelectValue placeholder="Select role" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableRoles.map((role) => (
                              <SelectItem key={role} value={role}>{role}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="grid grid-cols-1 gap-2">
                        <Label htmlFor={`model-${member.id}`}>Model</Label>
                        <Select
                          value={member.model}
                          onValueChange={(value) => 
                            handleUpdateMember(currentTeam, member.id, 'model', value)
                          }
                        >
                          <SelectTrigger id={`model-${member.id}`}>
                            <SelectValue placeholder="Select model" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableModels.map((model) => (
                              <SelectItem key={model} value={model}>{model}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                ))}
                
                {(!currentTeam.members || currentTeam.members.length === 0) && (
                  <div className="text-center py-4 text-muted-foreground">
                    No team members. Add at least one member.
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div>
              <div className="mb-4">
                <h4 className="text-sm font-medium mb-1">Strategy</h4>
                <div className="flex items-center">
                  <Badge variant="outline" className="capitalize">
                    {team.strategy}
                  </Badge>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Team Members</h4>
                {team.members?.length ? (
                  <ul className="space-y-2">
                    {team.members.map((member) => (
                      <li key={member.id} className="flex items-center justify-between border-b pb-2">
                        <div>
                          <span className="font-medium">{member.role}</span>
                          <p className="text-sm text-muted-foreground">{member.model}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-sm text-muted-foreground">No members in this team</div>
                )}
              </div>
            </div>
          )}
        </CardContent>
        
        <CardFooter className="flex justify-between">
          {isEditing ? (
            <>
              <Button
                variant="ghost"
                onClick={() => setEditingTeam(null)}
              >
                Cancel
              </Button>
              <Button
                onClick={() => updateTeamMutation.mutate(currentTeam)}
                disabled={updateTeamMutation.isPending}
              >
                {updateTeamMutation.isPending ? (
                  <>Saving...</>
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-1" /> Save Changes
                  </>
                )}
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={() => setEditingTeam(team)}
              >
                <Edit className="h-4 w-4 mr-1" /> Edit
              </Button>
              <Button
                variant="destructive"
                onClick={() => deleteTeamMutation.mutate(team.id)}
                disabled={deleteTeamMutation.isPending}
              >
                {deleteTeamMutation.isPending ? (
                  <>Deleting...</>
                ) : (
                  <>
                    <Trash2 className="h-4 w-4 mr-1" /> Delete
                  </>
                )}
              </Button>
            </>
          )}
        </CardFooter>
      </Card>
    );
  };

  // Create new team form
  const CreateTeamForm = () => (
    <Card>
      <CardHeader>
        <CardTitle>Create New Team</CardTitle>
        <CardDescription>Configure a new AI team for collaboration</CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid gap-2">
          <Label htmlFor="team-name">Team Name</Label>
          <Input
            id="team-name"
            placeholder="Enter team name"
            value={newTeam.name}
            onChange={(e) => setNewTeam({ ...newTeam, name: e.target.value })}
          />
        </div>
        
        <div className="grid gap-2">
          <Label htmlFor="team-description">Description</Label>
          <Input
            id="team-description"
            placeholder="Enter team description"
            value={newTeam.description}
            onChange={(e) => setNewTeam({ ...newTeam, description: e.target.value })}
          />
        </div>
        
        <div className="grid gap-2">
          <Label htmlFor="team-strategy">Collaboration Strategy</Label>
          <Select
            value={newTeam.strategy}
            onValueChange={(value: CollaborationStrategy) => 
              setNewTeam({ ...newTeam, strategy: value })
            }
          >
            <SelectTrigger id="team-strategy">
              <SelectValue placeholder="Select strategy" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sequential">Sequential</SelectItem>
              <SelectItem value="parallel">Parallel</SelectItem>
              <SelectItem value="hierarchical">Hierarchical</SelectItem>
              <SelectItem value="adaptive">Adaptive</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-2">
            <Label>Team Members</Label>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => handleAddMember(newTeam)}
            >
              <Plus className="h-4 w-4 mr-1" /> Add Member
            </Button>
          </div>
          
          {newTeam.members?.map((member) => (
            <div key={member.id} className="border rounded-md p-3 mb-2">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium">Member</span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveMember(newTeam, member.id)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              <div className="grid gap-2">
                <div className="grid grid-cols-1 gap-2">
                  <Label htmlFor={`role-${member.id}`}>Role</Label>
                  <Select
                    value={member.role}
                    onValueChange={(value) => 
                      handleUpdateMember(newTeam, member.id, 'role', value)
                    }
                  >
                    <SelectTrigger id={`role-${member.id}`}>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableRoles.map((role) => (
                        <SelectItem key={role} value={role}>{role}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-1 gap-2">
                  <Label htmlFor={`model-${member.id}`}>Model</Label>
                  <Select
                    value={member.model}
                    onValueChange={(value) => 
                      handleUpdateMember(newTeam, member.id, 'model', value)
                    }
                  >
                    <SelectTrigger id={`model-${member.id}`}>
                      <SelectValue placeholder="Select model" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableModels.map((model) => (
                        <SelectItem key={model} value={model}>{model}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          ))}
          
          {(!newTeam.members || newTeam.members.length === 0) && (
            <div className="text-center py-4 text-muted-foreground border rounded-md">
              No team members. Add at least one member.
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between">
        <Button
          variant="ghost"
          onClick={() => setIsCreatingTeam(false)}
        >
          Cancel
        </Button>
        <Button
          onClick={() => createTeamMutation.mutate(newTeam)}
          disabled={
            createTeamMutation.isPending || 
            !newTeam.name || 
            !newTeam.members?.length || 
            newTeam.members.some(m => !m.role || !m.model)
          }
        >
          {createTeamMutation.isPending ? (
            <>Creating...</>
          ) : (
            <>
              <Users className="h-4 w-4 mr-1" /> Create Team
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );

  // Teams content
  const teamsContent = () => {
    if (teamsLoading) {
      return (
        <div className="flex justify-center items-center h-64">
          <p className="text-muted-foreground">Loading teams...</p>
        </div>
      );
    }

    if (teamsError) {
      return (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load teams. Please try again later.
          </AlertDescription>
        </Alert>
      );
    }

    const teams = teamsData?.success ? teamsData.teams || [] : [];

    if (teams.length === 0 && !isCreatingTeam) {
      return (
        <div className="text-center p-12 border rounded-lg">
          <h3 className="text-lg font-semibold mb-2">No Teams Found</h3>
          <p className="text-muted-foreground mb-6">Create your first AI team to start collaborating</p>
          <Button onClick={() => setIsCreatingTeam(true)}>
            <Plus className="h-4 w-4 mr-1" /> Create New Team
          </Button>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        {!isCreatingTeam && (
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Your Teams</h3>
            <Button onClick={() => setIsCreatingTeam(true)}>
              <Plus className="h-4 w-4 mr-1" /> Create New Team
            </Button>
          </div>
        )}
        
        {isCreatingTeam && <CreateTeamForm />}
        
        {!isCreatingTeam && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {teams.map((team) => (
              <TeamCard key={team.id} team={team} />
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <TabsContent value="team" className="space-y-4">
      <div>
        <h2 className="text-2xl font-bold">AI Teams</h2>
        <p className="text-muted-foreground">
          Create and manage your AI team configurations
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="my-teams">My Teams</TabsTrigger>
          <TabsTrigger value="shared-teams">Shared With Me</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>
        
        <div className="mt-4">
          <TabsContent value="my-teams">
            {teamsContent()}
          </TabsContent>
          
          <TabsContent value="shared-teams">
            <div className="text-center p-12 border rounded-lg">
              <h3 className="text-lg font-semibold mb-2">No Shared Teams</h3>
              <p className="text-muted-foreground">
                Teams shared with you will appear here
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="templates">
            <ScrollArea className="h-[500px] rounded-md border p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Software Development Team</CardTitle>
                    <CardDescription>A team for software development tasks</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div>
                        <h4 className="text-sm font-medium">Strategy</h4>
                        <Badge variant="outline">Sequential</Badge>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Members</h4>
                        <ul className="text-sm space-y-1">
                          <li>Project Manager (GPT-4)</li>
                          <li>Software Architect (GPT-4)</li>
                          <li>Developer (Claude-2)</li>
                          <li>QA Engineer (GPT-3.5-turbo)</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Use Template</Button>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Content Creation Team</CardTitle>
                    <CardDescription>A team for creating marketing content</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div>
                        <h4 className="text-sm font-medium">Strategy</h4>
                        <Badge variant="outline">Hierarchical</Badge>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Members</h4>
                        <ul className="text-sm space-y-1">
                          <li>Content Strategist (GPT-4)</li>
                          <li>Copywriter (Claude-2)</li>
                          <li>Editor (GPT-4)</li>
                          <li>Fact Checker (GPT-3.5-turbo)</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Use Template</Button>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Research Team</CardTitle>
                    <CardDescription>A team for academic research tasks</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div>
                        <h4 className="text-sm font-medium">Strategy</h4>
                        <Badge variant="outline">Parallel</Badge>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Members</h4>
                        <ul className="text-sm space-y-1">
                          <li>Research Lead (GPT-4)</li>
                          <li>Data Analyst (Claude-2)</li>
                          <li>Literature Reviewer (GPT-4)</li>
                          <li>Technical Writer (Claude-2)</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">Use Template</Button>
                  </CardFooter>
                </Card>
              </div>
            </ScrollArea>
          </TabsContent>
        </div>
      </Tabs>
    </TabsContent>
  );
}