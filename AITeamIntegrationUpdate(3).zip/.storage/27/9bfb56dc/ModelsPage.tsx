import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { teamApi } from '@/lib/api';
import { AIModel } from '@/types/team';
import { TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Search, RefreshCw, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function ModelsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterProvider, setFilterProvider] = useState('');
  const [sortBy, setSortBy] = useState('name');

  // Query available AI models
  const { 
    data: modelsData, 
    isLoading: modelsLoading, 
    isError: modelsError,
    error: modelsErrorData,
    refetch: refetchModels 
  } = useQuery({
    queryKey: ['aiModels'],
    queryFn: () => teamApi.getAvailableModels(),
  });

  // Extract models from response
  const models: AIModel[] = modelsData?.success ? (modelsData.models || []) : [];

  // Get unique providers for filter
  const uniqueProviders = Array.from(
    new Set(models.map((model) => model.provider))
  );

  // Apply filters and sorting
  const filteredModels = models
    .filter((model) => 
      model.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      model.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter((model) => 
      filterProvider ? model.provider === filterProvider : true
    )
    .sort((a, b) => {
      if (sortBy === 'name') {
        return a.name.localeCompare(b.name);
      } else if (sortBy === 'provider') {
        return a.provider.localeCompare(b.provider);
      } else if (sortBy === 'cost') {
        return a.cost_per_1k_tokens - b.cost_per_1k_tokens;
      }
      return 0;
    });

  // Format cost as currency
  const formatCost = (cost: number) => {
    return `$${cost.toFixed(4)}`;
  };

  return (
    <TabsContent value="models" className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">AI Models</h2>
          <p className="text-muted-foreground">
            Explore available AI models and their capabilities
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => refetchModels()}
          disabled={modelsLoading}
        >
          <RefreshCw className="h-4 w-4 mr-1" />
          Refresh
        </Button>
      </div>

      {/* Search and filter controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search models..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <Select value={filterProvider} onValueChange={setFilterProvider}>
          <SelectTrigger>
            <SelectValue placeholder="Filter by provider" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Providers</SelectItem>
            {uniqueProviders.map((provider) => (
              <SelectItem key={provider} value={provider}>{provider}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger>
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Sort by Name</SelectItem>
            <SelectItem value="provider">Sort by Provider</SelectItem>
            <SelectItem value="cost">Sort by Cost</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Models display */}
      {modelsLoading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          <span className="ml-2 text-lg text-muted-foreground">Loading models...</span>
        </div>
      ) : modelsError ? (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>
            Failed to load AI models: {modelsErrorData instanceof Error ? modelsErrorData.message : 'Unknown error'}
          </AlertDescription>
        </Alert>
      ) : filteredModels.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center h-64">
            <p className="text-lg text-muted-foreground mb-4">No models found matching your criteria</p>
            {searchTerm || filterProvider ? (
              <Button variant="outline" onClick={() => { setSearchTerm(''); setFilterProvider(''); }}>
                Clear Filters
              </Button>
            ) : (
              <Button variant="outline" onClick={() => refetchModels()}>
                Refresh Models
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Available Models</CardTitle>
            <CardDescription>
              {filteredModels.length} models found
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Cost per 1k tokens</TableHead>
                  <TableHead>Suitable Roles</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredModels.map((model) => (
                  <TableRow key={model.id}>
                    <TableCell className="font-medium">{model.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {model.provider}
                      </Badge>
                    </TableCell>
                    <TableCell>{model.description}</TableCell>
                    <TableCell>{formatCost(model.cost_per_1k_tokens)}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {model.suitable_roles.map((role) => (
                          <Badge key={role} variant="secondary" className="text-xs">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
          <CardFooter className="text-sm text-muted-foreground">
            Costs are approximate and may vary based on usage patterns and provider pricing changes.
          </CardFooter>
        </Card>
      )}
    </TabsContent>
  );
}