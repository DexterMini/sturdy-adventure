import { useState } from 'react';
import { TabsContent } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AspectRatio } from '@/components/ui/aspect-ratio';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, ImageIcon, VideoIcon, CopyIcon, RefreshCw, Download, LayoutIcon, Share2 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { useMutation } from '@tanstack/react-query';
import { dexinityApi } from '@/lib/api';

export default function DexinityPage() {
  const [activeTab, setActiveTab] = useState('image-generator');
  const [imagePrompt, setImagePrompt] = useState('');
  const [videoPrompt, setVideoPrompt] = useState('');
  const [sketchFile, setSketchFile] = useState<File | null>(null);
  const [imageSettings, setImageSettings] = useState({
    style: 'realistic',
    ratio: '1:1',
    numberOfImages: 1,
    creativityLevel: 70,
    negativePrompt: ''
  });
  
  // Handle file upload for sketches
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSketchFile(file);
    }
  };
  
  // Image generation mutation
  const imageGenerationMutation = useMutation({
    mutationFn: (prompt: string) => dexinityApi.generateImages(prompt, imageSettings),
    onError: (error) => {
      console.error('Image generation error:', error);
    }
  });
  
  // Video generation mutation
  const videoGenerationMutation = useMutation({
    mutationFn: (prompt: string) => dexinityApi.generateVideo(prompt),
    onError: (error) => {
      console.error('Video generation error:', error);
    }
  });
  
  // Sketch to mockup mutation
  const sketchMockupMutation = useMutation({
    mutationFn: (file: File) => dexinityApi.convertSketchToMockup(file),
    onError: (error) => {
      console.error('Sketch conversion error:', error);
    }
  });

  // Generate images handler
  const handleGenerateImages = () => {
    if (!imagePrompt.trim()) return;
    imageGenerationMutation.mutate(imagePrompt);
  };
  
  // Generate video handler
  const handleGenerateVideo = () => {
    if (!videoPrompt.trim()) return;
    videoGenerationMutation.mutate(videoPrompt);
  };
  
  // Convert sketch handler
  const handleConvertSketch = () => {
    if (!sketchFile) return;
    sketchMockupMutation.mutate(sketchFile);
  };

  // Mock data for demonstration
  const mockGeneratedImages = [
    '/assets/images/generated-1.jpg',
    '/assets/images/generated-2.jpg'
  ];
  
  const mockGeneratedVideo = '/assets/videos/generated-video.mp4';
  
  const mockSketchConversion = {
    original: '/assets/images/sketch.jpg',
    mockup: '/assets/images/mockup.jpg'
  };

  return (
    <TabsContent value="dexinity" className="space-y-4">
      <div>
        <h2 className="text-2xl font-bold">Dexinity AI Studio</h2>
        <p className="text-muted-foreground">
          Creative AI tools for design and content creation
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="image-generator">Image Generator</TabsTrigger>
          <TabsTrigger value="video-generator">Video Generator</TabsTrigger>
          <TabsTrigger value="sketch-to-mockup">Sketch to Mockup</TabsTrigger>
          <TabsTrigger value="magic-resize">Magic Resize</TabsTrigger>
        </TabsList>
        
        {/* Image Generator Tab */}
        <TabsContent value="image-generator" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ImageIcon className="h-5 w-5 mr-2" /> Image Generator
              </CardTitle>
              <CardDescription>
                Create original AI-generated images from text descriptions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="image-prompt">Describe the image you want to create</Label>
                <Textarea
                  id="image-prompt"
                  placeholder="A futuristic cityscape with flying cars and neon lights, cyberpunk style, 8k, highly detailed"
                  rows={3}
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                />
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Image Style</Label>
                  <RadioGroup
                    value={imageSettings.style}
                    onValueChange={(value) => setImageSettings({...imageSettings, style: value})}
                    className="flex flex-wrap gap-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="realistic" id="realistic" />
                      <Label htmlFor="realistic">Realistic</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="artistic" id="artistic" />
                      <Label htmlFor="artistic">Artistic</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="cartoon" id="cartoon" />
                      <Label htmlFor="cartoon">Cartoon</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="anime" id="anime" />
                      <Label htmlFor="anime">Anime</Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-2">
                  <Label>Aspect Ratio</Label>
                  <Select
                    value={imageSettings.ratio}
                    onValueChange={(value) => setImageSettings({...imageSettings, ratio: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select aspect ratio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1:1">Square (1:1)</SelectItem>
                      <SelectItem value="16:9">Landscape (16:9)</SelectItem>
                      <SelectItem value="9:16">Portrait (9:16)</SelectItem>
                      <SelectItem value="4:3">Classic (4:3)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Number of Images</Label>
                    <span className="text-sm text-muted-foreground">
                      {imageSettings.numberOfImages}
                    </span>
                  </div>
                  <Slider
                    value={[imageSettings.numberOfImages]}
                    min={1}
                    max={4}
                    step={1}
                    onValueChange={(value) => setImageSettings({...imageSettings, numberOfImages: value[0]})}
                  />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Creativity Level</Label>
                    <span className="text-sm text-muted-foreground">
                      {imageSettings.creativityLevel}%
                    </span>
                  </div>
                  <Slider
                    value={[imageSettings.creativityLevel]}
                    min={0}
                    max={100}
                    step={5}
                    onValueChange={(value) => setImageSettings({...imageSettings, creativityLevel: value[0]})}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="negative-prompt">Negative Prompt (Optional)</Label>
                <Input
                  id="negative-prompt"
                  placeholder="Elements you don't want in the image"
                  value={imageSettings.negativePrompt}
                  onChange={(e) => setImageSettings({...imageSettings, negativePrompt: e.target.value})}
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => setImagePrompt('')}
              >
                Clear
              </Button>
              <Button 
                onClick={handleGenerateImages}
                disabled={imageGenerationMutation.isPending || !imagePrompt.trim()}
              >
                {imageGenerationMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Generating...
                  </>
                ) : (
                  'Generate Images'
                )}
              </Button>
            </CardFooter>
          </Card>
          
          {/* Show generated images or error */}
          {imageGenerationMutation.isSuccess && (
            <Card>
              <CardHeader>
                <CardTitle>Generated Images</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {(imageGenerationMutation.data?.images || mockGeneratedImages).map((image, index) => (
                    <div key={index} className="space-y-2">
                      <AspectRatio ratio={
                        imageSettings.ratio === '1:1' ? 1 : 
                        imageSettings.ratio === '16:9' ? 16/9 : 
                        imageSettings.ratio === '9:16' ? 9/16 : 
                        4/3
                      }>
                        <img 
                          src={image} 
                          alt={`Generated image ${index + 1}`} 
                          className="rounded-md object-cover w-full h-full" 
                        />
                      </AspectRatio>
                      <div className="flex justify-end space-x-2">
                        <Button size="sm" variant="outline">
                          <Download className="h-4 w-4 mr-1" /> Download
                        </Button>
                        <Button size="sm" variant="outline">
                          <Share2 className="h-4 w-4 mr-1" /> Share
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
          
          {imageGenerationMutation.isError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                Failed to generate images. Please try again with a different prompt.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>
        
        {/* Video Generator Tab */}
        <TabsContent value="video-generator" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <VideoIcon className="h-5 w-5 mr-2" /> Video Generator
              </CardTitle>
              <CardDescription>
                Create short AI-generated videos from text descriptions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="video-prompt">Describe the video you want to create</Label>
                <Textarea
                  id="video-prompt"
                  placeholder="A camera flying through a dense forest with sunlight filtering through the leaves, cinematic style"
                  rows={3}
                  value={videoPrompt}
                  onChange={(e) => setVideoPrompt(e.target.value)}
                />
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Video Duration</Label>
                  <Select defaultValue="3">
                    <SelectTrigger>
                      <SelectValue placeholder="Select duration" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 seconds</SelectItem>
                      <SelectItem value="3">3 seconds</SelectItem>
                      <SelectItem value="5">5 seconds</SelectItem>
                      <SelectItem value="8">8 seconds (Premium)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Video Style</Label>
                  <Select defaultValue="cinematic">
                    <SelectTrigger>
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cinematic">Cinematic</SelectItem>
                      <SelectItem value="animation">Animation</SelectItem>
                      <SelectItem value="stylized">Stylized</SelectItem>
                      <SelectItem value="realistic">Realistic</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Switch id="add-audio" />
                  <Label htmlFor="add-audio">Add generated audio (Beta)</Label>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button 
                variant="outline" 
                onClick={() => setVideoPrompt('')}
              >
                Clear
              </Button>
              <Button 
                onClick={handleGenerateVideo}
                disabled={videoGenerationMutation.isPending || !videoPrompt.trim()}
              >
                {videoGenerationMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Generating...
                  </>
                ) : (
                  'Generate Video'
                )}
              </Button>
            </CardFooter>
          </Card>
          
          {/* Show generated video or error */}
          {videoGenerationMutation.isSuccess && (
            <Card>
              <CardHeader>
                <CardTitle>Generated Video</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <AspectRatio ratio={16/9}>
                    <video 
                      controls 
                      className="rounded-md w-full h-full" 
                      src={videoGenerationMutation.data?.video || mockGeneratedVideo}
                    />
                  </AspectRatio>
                  <div className="flex justify-end space-x-2">
                    <Button size="sm" variant="outline">
                      <Download className="h-4 w-4 mr-1" /> Download
                    </Button>
                    <Button size="sm" variant="outline">
                      <Share2 className="h-4 w-4 mr-1" /> Share
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
          
          {videoGenerationMutation.isError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                Failed to generate video. Please try again with a different prompt.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>
        
        {/* Sketch to Mockup Tab */}
        <TabsContent value="sketch-to-mockup" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CopyIcon className="h-5 w-5 mr-2" /> Sketch to Mockup
              </CardTitle>
              <CardDescription>
                Convert hand-drawn sketches into polished digital mockups
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid w-full items-center gap-1.5">
                <Label htmlFor="sketch-upload">Upload Sketch</Label>
                <Input 
                  id="sketch-upload" 
                  type="file" 
                  accept="image/png, image/jpeg"
                  onChange={handleFileChange}
                />
                <p className="text-sm text-muted-foreground">
                  Supported formats: JPG, PNG. Max size: 5MB
                </p>
              </div>
              
              <Separator />
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Output Style</Label>
                  <Select defaultValue="wireframe">
                    <SelectTrigger>
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="wireframe">Wireframe</SelectItem>
                      <SelectItem value="ui">UI Design</SelectItem>
                      <SelectItem value="mobile">Mobile App</SelectItem>
                      <SelectItem value="web">Web Design</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Fidelity</Label>
                  <Select defaultValue="medium">
                    <SelectTrigger>
                      <SelectValue placeholder="Select fidelity" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (Sketch-like)</SelectItem>
                      <SelectItem value="medium">Medium (Standard)</SelectItem>
                      <SelectItem value="high">High (Detailed)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch id="keep-colors" defaultChecked />
                <Label htmlFor="keep-colors">Maintain original color scheme</Label>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button 
                onClick={handleConvertSketch}
                disabled={sketchMockupMutation.isPending || !sketchFile}
              >
                {sketchMockupMutation.isPending ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Converting...
                  </>
                ) : (
                  'Convert to Mockup'
                )}
              </Button>
            </CardFooter>
          </Card>
          
          {/* Show converted mockup or error */}
          {sketchMockupMutation.isSuccess && (
            <Card>
              <CardHeader>
                <CardTitle>Sketch to Mockup Result</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Original Sketch</h3>
                    <AspectRatio ratio={4/3}>
                      <img 
                        src={sketchMockupMutation.data?.original || mockSketchConversion.original} 
                        alt="Original sketch" 
                        className="rounded-md object-cover w-full h-full border" 
                      />
                    </AspectRatio>
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Generated Mockup</h3>
                    <AspectRatio ratio={4/3}>
                      <img 
                        src={sketchMockupMutation.data?.mockup || mockSketchConversion.mockup} 
                        alt="Generated mockup" 
                        className="rounded-md object-cover w-full h-full" 
                      />
                    </AspectRatio>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-2 mt-4">
                  <Button size="sm" variant="outline">
                    <Download className="h-4 w-4 mr-1" /> Download
                  </Button>
                  <Button size="sm" variant="outline">
                    <Share2 className="h-4 w-4 mr-1" /> Share
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
          
          {sketchMockupMutation.isError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>
                Failed to convert sketch. Please try with a clearer image.
              </AlertDescription>
            </Alert>
          )}
        </TabsContent>
        
        {/* Magic Resize Tab */}
        <TabsContent value="magic-resize" className="space-y-4 pt-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <LayoutIcon className="h-5 w-5 mr-2" /> Magic Resize
              </CardTitle>
              <CardDescription>
                Intelligently resize and adapt images for different platforms while preserving the main content
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid w-full items-center gap-1.5">
                  <Label htmlFor="image-upload">Upload Image to Resize</Label>
                  <Input 
                    id="image-upload" 
                    type="file" 
                    accept="image/png, image/jpeg"
                  />
                  <p className="text-sm text-muted-foreground">
                    Supported formats: JPG, PNG. Max size: 10MB
                  </p>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="instagram-post" />
                      <Label htmlFor="instagram-post">Instagram Post</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">1080 × 1080px</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="instagram-story" />
                      <Label htmlFor="instagram-story">Instagram Story</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">1080 × 1920px</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="facebook-post" />
                      <Label htmlFor="facebook-post">Facebook Post</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">1200 × 630px</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="twitter-post" />
                      <Label htmlFor="twitter-post">Twitter Post</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">1600 × 900px</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="linkedin-post" />
                      <Label htmlFor="linkedin-post">LinkedIn Post</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">1200 × 627px</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="youtube-thumbnail" />
                      <Label htmlFor="youtube-thumbnail">YouTube Thumbnail</Label>
                    </div>
                    <p className="text-xs text-muted-foreground">1280 × 720px</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="custom-size" />
                      <Label htmlFor="custom-size">Custom Size</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        placeholder="Width"
                        className="w-[70px]"
                      />
                      <span>×</span>
                      <Input
                        type="number"
                        placeholder="Height"
                        className="w-[70px]"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label>Smart Content Preservation</Label>
                    <span className="text-sm text-muted-foreground">75%</span>
                  </div>
                  <Slider defaultValue={[75]} max={100} step={1} />
                  <p className="text-xs text-muted-foreground">
                    Higher values prioritize main subject preservation over composition
                  </p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button>
                Resize Images
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </TabsContent>
  );
}

// Placeholder for Checkbox component that might be missing
const Checkbox = (props: React.InputHTMLAttributes<HTMLInputElement>) => {
  return (
    <input
      type="checkbox"
      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
      {...props}
    />
  );
};